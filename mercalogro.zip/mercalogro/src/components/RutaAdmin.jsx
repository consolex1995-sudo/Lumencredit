import { useEffect, useState } from 'react'
import { Navigate } from 'react-router-dom'

const CLAVE_SESION_ADMIN = 'mercalogro_admin_sesion'
const DURACION_SESION_MS = 8 * 60 * 60 * 1000

export function crearSesionAdmin() {
  const expira = Date.now() + DURACION_SESION_MS
  localStorage.setItem(CLAVE_SESION_ADMIN, JSON.stringify({ expira }))
}

export function cerrarSesionAdmin() {
  localStorage.removeItem(CLAVE_SESION_ADMIN)
}

export function sesionAdminValida() {
  try {
    const raw = localStorage.getItem(CLAVE_SESION_ADMIN)
    if (!raw) return false
    const { expira } = JSON.parse(raw)
    if (!expira || Date.now() > expira) {
      localStorage.removeItem(CLAVE_SESION_ADMIN)
      return false
    }
    return true
  } catch {
    return false
  }
}

export default function RutaAdmin({ children }) {
  const [estado, setEstado] = useState('cargando')

  useEffect(() => {
    setEstado(sesionAdminValida() ? 'autorizado' : 'no-autorizado')
  }, [])

  if (estado === 'cargando') {
    return (
      <div className="min-h-screen flex items-center justify-center bg-fondoClaro">
        <div className="w-8 h-8 border-4 border-principal border-t-transparent rounded-full animate-spin" />
      </div>
    )
  }

  if (estado === 'no-autorizado') {
    return <Navigate to="/" replace />
  }

  return children
}