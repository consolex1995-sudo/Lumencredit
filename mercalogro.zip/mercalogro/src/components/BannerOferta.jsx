import { useEffect, useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'

const CLAVE = 'mercalogro_banner_oferta_cierre'
const SEIS_HORAS = 6 * 60 * 60 * 1000

export default function BannerOferta() {
  const [visible, setVisible] = useState(false)

  useEffect(() => {
    try {
      const raw = localStorage.getItem(CLAVE)
      if (raw) {
        const { cerradoEn } = JSON.parse(raw)
        if (cerradoEn && Date.now() - cerradoEn < SEIS_HORAS) {
          setVisible(false)
          return
        }
      }
    } catch {}
    setVisible(true)
  }, [])

  function cerrar() {
    localStorage.setItem(CLAVE, JSON.stringify({ cerradoEn: Date.now() }))
    setVisible(false)
  }

  return (
    <AnimatePresence>
      {visible && (
        <motion.div
          initial={{ opacity: 0, y: -16 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -16 }}
          transition={{ duration: 0.3, ease: 'easeOut' }}
          className="relative bg-gradient-to-r from-principal to-emerald-700 text-white"
        >
          <div className="max-w-6xl mx-auto px-4 py-4 flex items-center justify-between gap-4">
            <div>
              <p className="text-sm md:text-base font-extrabold tracking-wide uppercase">
                Oferta flash Buen Fin
              </p>
              <p className="text-xs md:text-sm text-emerald-50">
                Adquiere tu Xbox Series X a 6 pagos antes del 15 de diciembre.
              </p>
            </div>
            <a
              href="/?categoria=consolas"
              className="shrink-0 bg-white text-principal text-xs md:text-sm font-bold px-4 py-2 rounded-full hover:bg-emerald-50 transition-colors"
            >
              Ver ofertas
            </a>
          </div>
          <button
            onClick={cerrar}
            aria-label="Cerrar oferta"
            className="absolute top-2 right-2 text-white/80 hover:text-white text-2xl leading-none"
          >
            ×
          </button>
        </motion.div>
      )}
    </AnimatePresence>
  )
}