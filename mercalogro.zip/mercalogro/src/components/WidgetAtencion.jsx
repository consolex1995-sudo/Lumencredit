import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'

const PREGUNTAS_BOT = [
  {
    id: 'bodega',
    pregunta: '¿Dónde recojo mi producto?',
    respuesta: 'Puedes recoger tu producto en nuestro Módulo de Recolección y Socios Logísticos dentro de Plaza Galerías Constituyentes, Av. Constituyentes Ote. #34, Local Comercial B-12 (Zona de Servicios / Recepción Logística), Colonia Mercurio, C.P. 76040, Santiago de Querétaro, Querétaro.\n\nAl llegar, dirígete a la Zona de Servicios y menciona que vienes por un pedido de Mercalogro. El horario es de lunes a sábado de 10:00 a 19:00 horas.'
  },
  {
    id: 'pago-inicial',
    pregunta: '¿Cuándo pago el 10% inicial?',
    respuesta: 'El pago inicial es requerido una vez que tu compra ha sido aprobada. Corresponde al 10% sobre el valor total del producto ordenado.'
  },
  {
    id: 'tiendas',
    pregunta: '¿En qué tiendas puedo pagar?',
    respuesta: 'Puedes pagar en Walmart, Bodega Aurrerá, Walmart Express, 7-Eleven, Farmacias del Ahorro y Soriana. Al generar tu referencia desde la página, se te indicará el proveedor y la comisión específica de la tienda que elegiste.'
  },
  {
    id: 'aprobacion',
    pregunta: '¿Cuánto tarda la aprobación?',
    respuesta: 'La revisión de tu solicitud puede tardar hasta 24 horas hábiles. Te notificaremos el resultado directamente en la página cuando consultes el estado de tu solicitud.'
  }
]

export default function WidgetAtencion() {
  const [abierto, setAbierto] = useState(false)
  const [respuestaActiva, setRespuestaActiva] = useState(null)

  function toggle() {
    setAbierto((a) => !a)
    if (abierto) setRespuestaActiva(null)
  }

  return (
    <div className="fixed bottom-4 right-4 z-40">
      <AnimatePresence>
        {abierto && (
          <motion.div
            initial={{ opacity: 0, y: 10, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 10, scale: 0.95 }}
            transition={{ duration: 0.2 }}
            className="mb-3 w-80 bg-white rounded-2xl shadow-xl border border-gray-100 overflow-hidden"
          >
            <div className="bg-principal px-4 py-3 flex items-center justify-between">
              <span className="text-white text-sm font-bold">Atención Mercalogro</span>
              <button onClick={toggle} className="text-white/80 hover:text-white">
                <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
                  <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            </div>
            <div className="p-3 space-y-2 max-h-72 overflow-y-auto">
              {!respuestaActiva ? (
                PREGUNTAS_BOT.map((p) => (
                  <button
                    key={p.id}
                    onClick={() => setRespuestaActiva(p)}
                    className="w-full text-left px-3 py-2 rounded-xl bg-fondoClaro text-xs font-semibold text-textoOscuro hover:bg-emerald-50 transition-colors"
                  >
                    {p.pregunta}
                  </button>
                ))
              ) : (
                <div className="space-y-2">
                  <button
                    onClick={() => setRespuestaActiva(null)}
                    className="text-[11px] text-principal font-semibold hover:underline"
                  >
                    ← Volver a preguntas
                  </button>
                  <p className="text-xs text-gray-600 leading-relaxed whitespace-pre-line">
                    {respuestaActiva.respuesta}
                  </p>
                </div>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
      <motion.button
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
        onClick={toggle}
        className="w-14 h-14 rounded-full bg-principal text-white shadow-lg flex items-center justify-center"
      >
        {abierto ? (
          <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
          </svg>
        ) : (
          <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z" />
          </svg>
        )}
      </motion.button>
    </div>
  )
}