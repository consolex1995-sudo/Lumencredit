import { Link } from 'react-router-dom'
import { motion } from 'framer-motion'

function formatoMoneda(n) {
  return n.toLocaleString('es-MX', { style: 'currency', currency: 'MXN', maximumFractionDigits: 0 })
}

export default function TarjetaProducto({ producto, index = 0 }) {
  const {
    id,
    nombre,
    imagen,
    precioContado,
    precioPlazos,
    precioAnterior,
    stockBajo,
    altaDemanda
  } = producto

  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.25, delay: Math.min(index * 0.04, 0.3), ease: 'easeOut' }}
      whileHover={{ y: -4 }}
      className="group bg-white rounded-2xl border border-gray-100 shadow-sm hover:shadow-lg transition-shadow flex flex-col overflow-hidden"
    >
      <Link to={`/producto/${id}`} className="block relative">
        <div className="aspect-square bg-gray-50 flex items-center justify-center overflow-hidden">
          {imagen ? (
            <img
              src={imagen}
              alt={nombre}
              loading="lazy"
              className="w-full h-full object-contain p-4 group-hover:scale-105 transition-transform duration-300"
            />
          ) : (
            <span className="text-gray-300 text-sm">Sin imagen</span>
          )}
        </div>

        <div className="absolute top-3 left-3 flex flex-col gap-1">
          {altaDemanda && (
            <span className="bg-acento text-white text-[10px] font-bold px-2 py-1 rounded-full shadow">
              ALTA DEMANDA
            </span>
          )}
          {stockBajo && (
            <span className="bg-red-600 text-white text-[10px] font-bold px-2 py-1 rounded-full shadow">
              SE AGOTA
            </span>
          )}
        </div>
      </Link>

      <div className="p-4 flex flex-col flex-1 gap-2">
        <Link to={`/producto/${id}`}>
          <h3 className="text-sm font-semibold text-textoOscuro leading-snug line-clamp-2 hover:text-principal transition-colors">
            {nombre}
          </h3>
        </Link>

        <div className="mt-auto">
          {precioAnterior && precioAnterior > precioContado && (
            <p className="text-xs text-gray-400 line-through">
              {formatoMoneda(precioAnterior)}
            </p>
          )}

          <p className="text-lg font-extrabold text-textoOscuro">
            {formatoMoneda(precioContado)}
          </p>
          <p className="text-xs text-gray-500">Precio de contado</p>

          {precioPlazos && (
            <p className="text-xs text-principal font-semibold mt-1">
              o 6 pagos de {formatoMoneda(Math.round(precioPlazos / 6))} al mes
            </p>
          )}
        </div>

        <Link to={`/producto/${id}`}>
          <motion.span
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            className="mt-2 block text-center bg-principal text-white text-sm font-semibold py-2.5 rounded-xl hover:bg-emerald-800 transition-colors"
          >
            Comprar
          </motion.span>
        </Link>
      </div>
    </motion.div>
  )
}