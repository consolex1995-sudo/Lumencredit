import { useEffect, useState } from 'react'
import { Link, useLocation } from 'react-router-dom'
import { motion, AnimatePresence } from 'framer-motion'

export default function BannerSolicitud() {
  const [visible, setVisible] = useState(false)
  const location = useLocation()

  useEffect(() => {
    let activo = true

    function revisar() {
      try {
        const raw = localStorage.getItem('mercalogro_solicitud_pendiente')
        if (activo) setVisible(!!raw)
      } catch {
        if (activo) setVisible(false)
      }
    }

    revisar()
    const intervalo = setInterval(revisar, 30000)

    return () => {
      activo = false
      clearInterval(intervalo)
    }
  }, [])

  if (!visible) return null
  if (location.pathname.startsWith('/solicitud')) return null

  return (
    <AnimatePresence>
      <motion.div
        initial={{ y: 80, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        exit={{ y: 80, opacity: 0 }}
        transition={{ duration: 0.3, ease: 'easeOut' }}
        className="fixed bottom-0 left-0 right-0 z-40 bg-white border-t border-gray-200 shadow-lg"
      >
        <div className="max-w-6xl mx-auto px-4 py-3 flex items-center justify-between gap-3">
          <p className="text-sm text-textoOscuro">
            Tienes una solicitud en curso.
          </p>
          <Link to="/solicitud/estado">
            <motion.span
              whileHover={{ scale: 1.03 }}
              whileTap={{ scale: 0.97 }}
              className="inline-block bg-principal text-white text-sm font-semibold px-4 py-2 rounded-xl hover:bg-emerald-800 transition-colors"
            >
              Regresar a mi solicitud
            </motion.span>
          </Link>
        </div>
      </motion.div>
    </AnimatePresence>
  )
}