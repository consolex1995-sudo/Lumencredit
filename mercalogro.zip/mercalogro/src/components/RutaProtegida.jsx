import { useEffect, useState } from 'react'
import { Navigate, useLocation } from 'react-router-dom'
import { supabase } from '../lib/supabase.js'

export default function RutaProtegida({ children }) {
  const [estado, setEstado] = useState('cargando')
  const location = useLocation()

  useEffect(() => {
    let activo = true

    async function verificar() {
      const { data } = await supabase.auth.getSession()
      if (!activo) return
      setEstado(data?.session ? 'autorizado' : 'no-autorizado')
    }

    verificar()

    const { data: listener } = supabase.auth.onAuthStateChange((_event, session) => {
      setEstado(session ? 'autorizado' : 'no-autorizado')
    })

    return () => {
      activo = false
      listener?.subscription?.unsubscribe?.()
    }
  }, [])

  if (estado === 'cargando') {
    return (
      <div className="min-h-screen flex items-center justify-center bg-fondoClaro">
        <div className="w-8 h-8 border-4 border-principal border-t-transparent rounded-full animate-spin" />
      </div>
    )
  }

  if (estado === 'no-autorizado') {
    return <Navigate to="/" state={{ from: location }} replace />
  }

  return children
}