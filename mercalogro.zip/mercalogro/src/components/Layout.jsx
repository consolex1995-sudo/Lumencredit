import { Link, useNavigate } from 'react-router-dom'
import { motion } from 'framer-motion'
import { useEffect, useState } from 'react'
import { supabase } from '../lib/supabase.js'
import { sesionAdminValida } from './RutaAdmin.jsx'

export default function Layout({ children, mostrarBuscador = false }) {
  const navigate = useNavigate()
  const [sesion, setSesion] = useState(null)

  useEffect(() => {
    let activo = true
    supabase.auth.getSession().then(({ data }) => {
      if (activo) setSesion(data?.session ?? null)
    })
    const { data: listener } = supabase.auth.onAuthStateChange((_event, session) => {
      setSesion(session ?? null)
    })
    return () => {
      activo = false
      listener?.subscription?.unsubscribe?.()
    }
  }, [])

  async function cerrarSesion() {
    await supabase.auth.signOut()
    navigate('/')
  }

  return (
    <div className="min-h-screen flex flex-col bg-fondoClaro">
      <header className="sticky top-0 z-40 bg-white shadow-sm">
        <div className="max-w-6xl mx-auto px-4 h-16 flex items-center justify-between gap-4">
          <Link to="/" className="flex items-center gap-2">
            <motion.span
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="text-2xl font-extrabold text-principal tracking-tight"
            >
              Mercalogro
            </motion.span>
          </Link>

          <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-textoOscuro">
            <Link to="/" className="hover:text-principal transition-colors">Tienda</Link>
            <Link to="/preguntas-frecuentes" className="hover:text-principal transition-colors">Preguntas</Link>
            <Link to="/testimonios" className="hover:text-principal transition-colors">Testimonios</Link>
          </nav>

          <div className="flex items-center gap-3">
            {sesion ? (
              <>
                <Link
                  to="/mi-cuenta"
                  className="text-sm font-semibold text-principal hover:underline"
                >
                  Mi cuenta
                </Link>
                <button
                  onClick={cerrarSesion}
                  className="text-sm text-gray-500 hover:text-gray-800"
                >
                  Cerrar sesión
                </button>
              </>
            ) : (
              <Link
                to="/mi-cuenta"
                className="text-sm font-semibold text-principal hover:underline"
              >
                Iniciar sesión
              </Link>
            )}
          </div>
        </div>
      </header>

      <main className="flex-1">{children}</main>

      <footer className="bg-textoOscuro text-gray-300 text-sm mt-12">
        <div className="max-w-6xl mx-auto px-4 py-10 grid gap-8 md:grid-cols-3">
          <div>
            <p className="text-white font-bold text-lg mb-2">Mercalogro</p>
            <p className="text-gray-400">
              Compra consolas, videojuegos y accesorios a plazos o de contado.
            </p>
          </div>
          <div className="flex flex-col gap-2">
            <Link to="/preguntas-frecuentes" className="hover:text-white transition-colors">Preguntas frecuentes</Link>
            <Link to="/legales" className="hover:text-white transition-colors">Términos y condiciones</Link>
            <Link to="/legales" className="hover:text-white transition-colors">Aviso de privacidad</Link>
            <Link to="/testimonios" className="hover:text-white transition-colors">Testimonios</Link>
          </div>
          <div className="text-gray-400">
            <p>Mercalogro — Todos los derechos reservados.</p>
            <p className="mt-2">Envíos a todo México.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}