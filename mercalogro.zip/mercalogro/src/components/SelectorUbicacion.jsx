import { useEffect, useState } from 'react'
import { motion } from 'framer-motion'

const ESTADOS_MX = [
  'Aguascalientes', 'Baja California', 'Baja California Sur', 'Campeche', 'Chiapas',
  'Chihuahua', 'Ciudad de México', 'Coahuila', 'Colima', 'Durango', 'Estado de México',
  'Guanajuato', 'Guerrero', 'Hidalgo', 'Jalisco', 'Michoacán', 'Morelos', 'Nayarit',
  'Nuevo León', 'Oaxaca', 'Puebla', 'Querétaro', 'Quintana Roo', 'San Luis Potosí',
  'Sinaloa', 'Sonora', 'Tabasco', 'Tamaulipas', 'Tlaxcala', 'Veracruz', 'Yucatán', 'Zacatecas'
]

const CLAVE = 'mercalogro_ubicacion'

export default function SelectorUbicacion() {
  const [estado, setEstado] = useState('')
  const [cp, setCp] = useState('')
  const [guardado, setGuardado] = useState(false)

  useEffect(() => {
    try {
      const raw = localStorage.getItem(CLAVE)
      if (raw) {
        const { estado: e, cp: c } = JSON.parse(raw)
        setEstado(e || '')
        setCp(c || '')
        setGuardado(true)
      }
    } catch {}
  }, [])

  function guardar() {
    if (!estado) return
    const limpioCp = cp.replace(/\D/g, '').slice(0, 5)
    localStorage.setItem(CLAVE, JSON.stringify({ estado, cp: limpioCp }))
    setGuardado(true)
  }

  function cambiar() {
    setGuardado(false)
  }

  if (guardado) {
    return (
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="text-sm text-gray-600 flex items-center gap-2"
      >
        <span>
          Enviando a <strong className="text-textoOscuro">{estado}</strong>
          {cp ? ` — CP ${cp}` : ''}
        </span>
        <button
          onClick={cambiar}
          className="text-principal font-semibold hover:underline"
        >
          Cambiar
        </button>
      </motion.div>
    )
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 6 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.2 }}
      className="flex flex-col sm:flex-row gap-2 items-stretch sm:items-center"
    >
      <select
        value={estado}
        onChange={(e) => setEstado(e.target.value)}
        className="px-3 py-2 rounded-lg border border-gray-300 bg-white text-sm outline-none focus:border-principal"
      >
        <option value="">Elige tu estado</option>
        {ESTADOS_MX.map((e) => (
          <option key={e} value={e}>{e}</option>
        ))}
      </select>

      <input
        type="text"
        inputMode="numeric"
        value={cp}
        onChange={(e) => setCp(e.target.value.replace(/\D/g, '').slice(0, 5))}
        placeholder="Código postal (opcional)"
        className="px-3 py-2 rounded-lg border border-gray-300 bg-white text-sm outline-none focus:border-principal w-full sm:w-44"
      />

      <motion.button
        whileHover={{ scale: 1.02 }}
        whileTap={{ scale: 0.98 }}
        onClick={guardar}
        disabled={!estado}
        className="px-4 py-2 bg-principal text-white text-sm font-semibold rounded-lg disabled:opacity-40 hover:bg-emerald-800 transition-colors"
      >
        Guardar
      </motion.button>
    </motion.div>
  )
}