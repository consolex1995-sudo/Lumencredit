import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { motion } from 'framer-motion'

export default function Buscador({ placeholder = 'Busca consolas, juegos, accesorios…' }) {
  const [texto, setTexto] = useState('')
  const navigate = useNavigate()

  function enviar(e) {
    e.preventDefault()
    const limpio = texto.trim()
    if (!limpio) return
    navigate(`/?q=${encodeURIComponent(limpio)}`)
  }

  return (
    <motion.form
      onSubmit={enviar}
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.25, ease: 'easeOut' }}
      className="w-full"
    >
      <div className="flex items-center bg-white rounded-full shadow-md overflow-hidden border border-gray-200 focus-within:border-principal transition-colors">
        <input
          type="text"
          value={texto}
          onChange={(e) => setTexto(e.target.value)}
          placeholder={placeholder}
          className="flex-1 px-5 py-3 text-sm outline-none bg-transparent text-textoOscuro placeholder-gray-400"
        />
        <motion.button
          type="submit"
          whileHover={{ scale: 1.03 }}
          whileTap={{ scale: 0.97 }}
          className="m-1 px-5 py-2.5 bg-principal text-white text-sm font-semibold rounded-full hover:bg-emerald-800 transition-colors"
        >
          Buscar
        </motion.button>
      </div>
    </motion.form>
  )
}