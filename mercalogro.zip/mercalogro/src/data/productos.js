export const productosPiloto = [
  {
    id: 'xbox-series-x',
    nombre: 'Xbox Series X 1TB',
    categoria: 'consolas',
    imagen: '/productos/xbox-series-x.webp',
    precioContado: 14999,
    precioAnterior: 16999,
    precioPlazos: 19950,
    stock: 5,
    stockBajo: true,
    altaDemanda: true,
    descripcion: 'La consola más potente de Xbox. 1TB de almacenamiento, 4K real y velocidad de carga ultrarrápida.'
  },
  {
    id: 'xbox-series-s',
    nombre: 'Xbox Series S 512GB Digital',
    categoria: 'consolas',
    imagen: '/productos/xbox-series-s.webp',
    precioContado: 7999,
    precioAnterior: 8999,
    precioPlazos: 10650,
    stock: 8,
    stockBajo: false,
    altaDemanda: true,
    descripcion: 'Consola digital compacta, ideal para gaming en 1440p. Incluye un control inalámbrico.'
  },
  {
    id: 'playstation-5-slim',
    nombre: 'PlayStation 5 Slim Digital',
    categoria: 'consolas',
    imagen: '/productos/ps5-slim.webp',
    precioContado: 12999,
    precioAnterior: 13999,
    precioPlazos: 17300,
    stock: 3,
    stockBajo: true,
    altaDemanda: true,
    descripcion: 'La nueva PS5 Slim en versión digital. 1TB de almacenamiento y gráficos de última generación.'
  },
  {
    id: 'control-xbox-inalambrico',
    nombre: 'Control Xbox inalámbrico',
    categoria: 'accesorios',
    imagen: '/productos/control-xbox.webp',
    precioContado: 1499,
    precioAnterior: null,
    precioPlazos: 1995,
    stock: 20,
    stockBajo: false,
    altaDemanda: false,
    descripcion: 'Control inalámbrico oficial de Xbox, compatible con consola, PC y móvil.'
  },
  {
    id: 'control-ps5-dualsense',
    nombre: 'Control PS5 DualSense',
    categoria: 'accesorios',
    imagen: '/productos/dualsense.webp',
    precioContado: 1699,
    precioAnterior: null,
    precioPlazos: 2260,
    stock: 15,
    stockBajo: false,
    altaDemanda: false,
    descripcion: 'Control DualSense con retroalimentación háptica y gatillos adaptativos.'
  },
  {
    id: 'gta-6',
    nombre: 'GTA VI — Preventa',
    categoria: 'juegos',
    imagen: '/productos/gta6.webp',
    precioContado: 1899,
    precioAnterior: null,
    precioPlazos: 2525,
    stock: 30,
    stockBajo: false,
    altaDemanda: true,
    descripcion: 'Preventa de GTA VI. Asegura tu copia antes del lanzamiento.'
  },
  {
    id: 'silla-gaming-pro',
    nombre: 'Silla gaming Pro',
    categoria: 'sillas',
    imagen: '/productos/silla-gaming.webp',
    precioContado: 4999,
    precioAnterior: 5999,
    precioPlazos: 6650,
    stock: 6,
    stockBajo: false,
    altaDemanda: false,
    descripcion: 'Silla gaming ergonómica con soporte lumbar, reclinable y base reforzada.'
  },
  {
    id: 'audifonos-gaming',
    nombre: 'Audífonos gaming con micrófono',
    categoria: 'accesorios',
    imagen: '/productos/audifonos.webp',
    precioContado: 899,
    precioAnterior: null,
    precioPlazos: 1195,
    stock: 25,
    stockBajo: false,
    altaDemanda: false,
    descripcion: 'Audífonos con sonido envolvente, micrófono ajustable y compatibilidad multiplataforma.'
  }
]

export const categorias = [
  { id: 'consolas', nombre: 'Consolas' },
  { id: 'juegos', nombre: 'Juegos' },
  { id: 'accesorios', nombre: 'Accesorios' },
  { id: 'sillas', nombre: 'Sillas' }
]