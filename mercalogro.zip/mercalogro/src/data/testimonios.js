export const testimonios = [
  {
    id: 1,
    nombre: 'Carlos M.',
    ciudad: 'Ciudad de México',
    calificacion: 5,
    producto: 'Xbox Series X',
    texto: 'Todo muy claro desde el principio. Me explicaron bien lo del pago inicial y el envío llegó en el tiempo prometido. La consola llegó sellada y en perfecto estado.'
  },
  {
    id: 2,
    nombre: 'Ana R.',
    ciudad: 'Guadalajara',
    calificacion: 5,
    producto: 'Silla gaming Pro',
    texto: 'Tenía dudas porque nunca había comprado a plazos en línea, pero el proceso fue sencillo. Me ayudaron por el chat cuando no entendía algo del pago en tienda.'
  },
  {
    id: 3,
    nombre: 'Luis F.',
    ciudad: 'Monterrey',
    calificacion: 4,
    producto: 'Control PS5 DualSense',
    texto: 'El control llegó bien y funciona perfecto. Lo único es que tardó un día más de lo que decía, pero me avisaron por el estado del pedido.'
  },
  {
    id: 4,
    nombre: 'María G.',
    ciudad: 'Puebla',
    calificacion: 5,
    producto: 'Xbox Series S',
    texto: 'Muy buena atención. El pago en la tienda fue rápido con el número de referencia y no tuve que dar datos de tarjeta. Eso me dio confianza.'
  },
  {
    id: 5,
    nombre: 'Jorge T.',
    ciudad: 'Querétaro',
    calificacion: 5,
    producto: 'GTA VI — Preventa',
    texto: 'Aproveché la preventa y quedó apartado sin problema. Me explicaron todo lo del pago inicial desde el inicio, sin sorpresas.'
  },
  {
    id: 6,
    nombre: 'Fernanda L.',
    ciudad: 'Tijuana',
    calificacion: 4,
    producto: 'Audífonos gaming',
    texto: 'Buena calidad los audífonos. El proceso de compra fue rápido y el pago en tienda fue sencillo. Sí los recomiendo.'
  },
  {
    id: 7,
    nombre: 'Ricardo S.',
    ciudad: 'León',
    calificacion: 5,
    producto: 'PlayStation 5 Slim',
    texto: 'Me dio confianza que todo se maneja desde la página y no por WhatsApp. El envío llegó bien empacado y la consola funciona perfecto.'
  },
  {
    id: 8,
    nombre: 'Daniela V.',
    ciudad: 'Mérida',
    calificacion: 5,
    producto: 'Control Xbox inalámbrico',
    texto: 'Compré un control de repuesto y llegó rapidísimo. El pago en OXXO fue fácil con la referencia que me dieron. Sin problemas.'
  }
]