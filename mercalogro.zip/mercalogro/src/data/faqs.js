export const faqs = [
  {
    id: 'pago-inicial',
    pregunta: '¿En qué momento es requerido el pago inicial?',
    respuesta: 'El pago inicial es requerido una vez que tu compra ha sido aprobada. Corresponde al 10% sobre el valor total del producto ordenado.'
  },
  {
    id: 'pago-bodega-recoleccion',
    pregunta: 'Elegí pago en bodega y recolección en bodega. ¿Qué debo hacer?',
    respuesta: 'Si seleccionaste la opción de pagar y recoger en nuestra bodega, debes acudir al Módulo de Recolección y Socios Logísticos ubicado en Interior Plaza Galerías Constituyentes, Av. Constituyentes Ote. #34, Local Comercial B-12 (Zona de Servicios / Recepción Logística), Colonia Mercurio, C.P. 76040, Santiago de Querétaro, Querétaro.\n\nAl llegar, dirígete a la Zona de Servicios / Recepción Logística y menciona que vienes a recoger un pedido de Mercalogro. Ahí podrás realizar tu pago inicial o mensualidades en efectivo o con tarjeta de crédito/débito directamente en el punto de venta. Una vez confirmado el pago, te entregarán tu producto en ese mismo módulo.\n\nRecuerda llevar tu identificación oficial y, si ya realizaste el pago previamente, tu comprobante o número de compra para agilizar la entrega. El horario de atención es de lunes a sábado de 10:00 a 19:00 horas.'
  },
  {
    id: 'recoger-bodega',
    pregunta: '¿Puedo recoger mi producto en la bodega?',
    respuesta: 'Sí. Si eliges la opción de recolección en bodega durante el proceso de pago, podrás recoger tu producto en nuestro Módulo de Recolección y Socios Logísticos dentro de Plaza Galerías Constituyentes, Av. Constituyentes Ote. #34, Local B-12, Zona de Servicios / Recepción Logística, Colonia Mercurio, C.P. 76040, Santiago de Querétaro, Querétaro.\n\nLa fecha exacta de disponibilidad será asignada por Mercalogro al aprobar tu compra y se mostrará en tu pantalla de pago. No puedes elegir la fecha; solo la consultas.'
  },
  {
    id: 'no-pago-inicial',
    pregunta: '¿Qué pasa si no pago mi pago inicial a tiempo?',
    respuesta: 'Si no realizas el pago inicial dentro del plazo establecido, tu compra se cancelará automáticamente y el producto se liberará a existencias. No se garantiza la disponibilidad del producto en un segundo intento.'
  },
  {
    id: 'tiempo-aprobacion',
    pregunta: '¿Cuánto tarda la aprobación de mi solicitud?',
    respuesta: 'La revisión de tu solicitud puede tardar hasta 24 horas hábiles. Te notificaremos el resultado directamente en la página cuando consultes el estado de tu solicitud. Puedes seguir navegando por la tienda mientras esperas.'
  },
  {
    id: 'documentos-necesarios',
    pregunta: '¿Qué documentos necesito para solicitar una compra a plazos?',
    respuesta: 'Solo necesitas tu INE vigente (frente) y tomarte una selfie durante el proceso. También te pediremos datos personales, laborales y de contacto. Toda la información debe ser real y verificable.'
  },
  {
    id: 'envio-gratis',
    pregunta: '¿El envío es gratis?',
    respuesta: 'Sí, el envío es gratuito cuando el pago se realiza en tiendas físicas participantes o en nuestra bodega. Si eliges envío a domicilio en compra de contado, el envío es gratis a partir de $600 MXN.'
  },
  {
    id: 'garantia',
    pregunta: '¿Los productos tienen garantía?',
    respuesta: 'Todos los productos cuentan con 1 año de garantía sin costo adicional contra defectos de fábrica. Si tu producto presenta una falla cubierta por la garantía, puedes solicitar la devolución sin costo alguno, incluyendo el envío de regreso.'
  },
  {
    id: 'devoluciones',
    pregunta: '¿Puedo devolver un producto?',
    respuesta: 'Sí. Si el producto está sin abrir, tienes 7 días para devolverlo (el costo de envío de devolución corre por tu cuenta). Si ya fue abierto, aplica una penalización del 17%. Si es falla de fábrica, la devolución es sin costo ni penalización dentro del año de garantía.'
  },
  {
    id: 'metodos-pago-tiendas',
    pregunta: '¿En qué tiendas puedo pagar mis mensualidades?',
    respuesta: 'Puedes pagar en Walmart, Bodega Aurrerá, Walmart Express, 7-Eleven, Farmacias del Ahorro y Soriana. Al generar tu referencia desde la página, se te indicará el proveedor de pago (PESPay o Dapp) y la comisión específica de la tienda que elegiste.'
  }
]