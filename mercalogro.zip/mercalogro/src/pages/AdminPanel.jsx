import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { motion } from 'framer-motion'
import { cerrarSesionAdmin } from '../components/RutaAdmin.jsx'
import { supabase } from '../lib/supabase.js'
import AdminSolicitudes from './AdminSolicitudes.jsx'
import AdminCompras from './AdminCompras.jsx'
import AdminProductos from './AdminProductos.jsx'
import AdminComprobantes from './AdminComprobantes.jsx'

const SECCIONES = [
  { id: 'solicitudes', nombre: 'Solicitudes' },
  { id: 'compras', nombre: 'Compras' },
  { id: 'productos', nombre: 'Productos' },
  { id: 'comprobantes', nombre: 'Comprobantes' }
]

export default function AdminPanel() {
  const navigate = useNavigate()
  const [seccion, setSeccion] = useState('solicitudes')
  const [visitas, setVisitas] = useState(0)
  const [cargandoVisitas, setCargandoVisitas] = useState(true)

  useEffect(() => {
    let activo = true
    supabase
      .from('visitas')
      .select('*', { count: 'exact', head: true })
      .then(({ count }) => {
        if (activo) {
          setVisitas(count || 0)
          setCargandoVisitas(false)
        }
      })
    return () => {
      activo = false
    }
  }, [])

  function salir() {
    cerrarSesionAdmin()
    navigate('/', { replace: true })
  }

  return (
    <div className="min-h-screen bg-fondoClaro">
      <header className="bg-white border-b border-gray-100 sticky top-0 z-30">
        <div className="max-w-6xl mx-auto px-4 h-14 flex items-center justify-between">
          <p className="font-extrabold text-principal">Mercalogro · Admin</p>
          <button
            onClick={salir}
            className="text-sm text-gray-500 hover:text-red-600 transition-colors"
          >
            Cerrar sesión
          </button>
        </div>
      </header>

      <div className="max-w-6xl mx-auto px-4 py-6">
        <div className="grid sm:grid-cols-3 gap-3">
          <motion.div
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white rounded-2xl border border-gray-100 p-4"
          >
            <p className="text-xs text-gray-500">Visitas registradas</p>
            <p className="text-2xl font-extrabold text-textoOscuro mt-1">
              {cargandoVisitas ? '—' : visitas.toLocaleString('es-MX')}
            </p>
          </motion.div>
        </div>

        <div className="mt-6 flex gap-2 overflow-x-auto no-scrollbar">
          {SECCIONES.map((s) => (
            <button
              key={s.id}
              onClick={() => setSeccion(s.id)}
              className={`shrink-0 px-4 py-2 rounded-full text-sm font-semibold transition-colors ${
                seccion === s.id
                  ? 'bg-principal text-white'
                  : 'bg-white text-textoOscuro border border-gray-200 hover:border-principal'
              }`}
            >
              {s.nombre}
            </button>
          ))}
        </div>

        <motion.div
          key={seccion}
          initial={{ opacity: 0, y: 6 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.2 }}
          className="mt-5"
        >
          {seccion === 'solicitudes' && <AdminSolicitudes />}
          {seccion === 'compras' && <AdminCompras />}
          {seccion === 'productos' && <AdminProductos />}
          {seccion === 'comprobantes' && <AdminComprobantes />}
        </motion.div>
      </div>
    </div>
  )
}