import { useEffect, useState } from 'react'
import { useSearchParams, useNavigate } from 'react-router-dom'
import { motion, AnimatePresence } from 'framer-motion'
import Layout from '../components/Layout.jsx'
import WidgetAtencion from '../components/WidgetAtencion.jsx'
import { supabase } from '../lib/supabase.js'

function formatoMoneda(n) {
  return Number(n || 0).toLocaleString('es-MX', { style: 'currency', currency: 'MXN', maximumFractionDigits: 0 })
}

// DIRECCIÓN REAL DE BODEGA
const DIRECCION_BODEGA = 'Módulo de Recolección y Socios Logísticos - Interior Plaza Galerías Constituyentes, Av. Constituyentes Ote. #34, Local Comercial B-12 (Zona de Servicios / Recepción Logística), Colonia Mercurio, C.P. 76040, Santiago de Querétaro, Querétaro.'

// TIENDAS FÍSICAS DISPONIBLES
const TIENDAS = [
  { id: 'walmart', nombre: 'Walmart / Bodega Aurrerá / Express', logo: '/logos/walmart.webp', proveedor: 'PESPay' },
  { id: 'seven', nombre: '7-Eleven', logo: '/logos/seven.webp', proveedor: 'Dapp' },
  { id: 'ahorro', nombre: 'Farmacias del Ahorro', logo: '/logos/ahorro.webp', proveedor: 'PESPay' },
  { id: 'soriana', nombre: 'Soriana', logo: '/logos/soriana.webp', proveedor: 'Dapp' }
]

// MAPEO DE REFERENCIAS Y COMISIONES POR CUENTA ASIGNADA
// Cuando el admin asigne una cuenta, se usará esta estructura para mostrar los datos reales
const CUENTAS_CONFIG = {
  // CUENTA A (Dapp)
  'CUENTA_A': {
    Dapp: { ref: '028026208361', comisiones: { seven: 15, soriana: 12 } },
    PESPay: { ref: '10036314159275129028', comisiones: { walmart: 10, ahorro: 10 } }
  },
  // CUENTA B (PESPay principal + Dapp secundario)
  'CUENTA_B': {
    Dapp: { ref: '028994770529', comisiones: { seven: 15, soriana: 12 } },
    PESPay: { ref: '10036314159275640461', comisiones: { walmart: 10, ahorro: 10 } }
  },
  // PLACEHOLDERS PARA FUTURAS CUENTAS (se activarán cuando el dueño las proporcione)
  'CUENTA_C': {
    Dapp: { ref: 'PENDIENTE_CUENTA_C_DAPP', comisiones: { seven: 0, soriana: 0 } },
    PESPay: { ref: 'PENDIENTE_CUENTA_C_PESPAY', comisiones: { walmart: 0, ahorro: 0 } }
  },
  'CUENTA_D': {
    Dapp: { ref: 'PENDIENTE_CUENTA_D_DAPP', comisiones: { seven: 0, soriana: 0 } },
    PESPay: { ref: 'PENDIENTE_CUENTA_D_PESPAY', comisiones: { walmart: 0, ahorro: 0 } }
  },
  'CUENTA_E': {
    Dapp: { ref: 'PENDIENTE_CUENTA_E_DAPP', comisiones: { seven: 0, soriana: 0 } },
    PESPay: { ref: 'PENDIENTE_CUENTA_E_PESPAY', comisiones: { walmart: 0, ahorro: 0 } }
  }
}

export default function PagoInicial() {
  const [params] = useSearchParams()
  const navigate = useNavigate()
  const [compra, setCompra] = useState(null)
  const [cargando, setCargando] = useState(true)
  const [opcionElegida, setOpcionElegida] = useState(null) // 'bodega' | tienda object | 'tarjeta'
  const [error, setError] = useState('')
  const [modalYaPague, setModalYaPague] = useState(false)
  const [subiendo, setSubiendo] = useState(false)
  const [generandoRef, setGenerandoRef] = useState(false)
  const [refGenerada, setRefGenerada] = useState(false)

  useEffect(() => {
    let activo = true
    async function cargar() {
      const id = params.get('compra')
      if (!id) {
        if (activo) setCargando(false)
        return
      }
      const { data } = await supabase.from('compras').select('*').eq('id', id).maybeSingle()
      if (!activo) return
      setCompra(data)
      setCargando(false)
    }
    cargar()
    return () => { activo = false }
  }, [params])

  if (cargando) {
    return (
      <Layout>
        <div className="max-w-2xl mx-auto px-4 py-20 text-center">
          <div className="w-8 h-8 mx-auto border-4 border-principal border-t-transparent rounded-full animate-spin" />
        </div>
      </Layout>
    )
  }

  if (!compra) {
    return (
      <Layout>
        <div className="max-w-2xl mx-auto px-4 py-20 text-center">
          <p className="text-gray-500">No encontramos la compra.</p>
        </div>
      </Layout>
    )
  }

  const pagoInicial = Math.round((compra.precio_total || 0) * 0.1)
  const esBodega = opcionElegida === 'bodega'
  const esTarjeta = opcionElegida === 'tarjeta'
  const esTienda = opcionElegida && typeof opcionElegida === 'object'

  // Obtener referencia y comisión según cuenta asignada por admin
  const cuentaAsignada = compra.cuenta_asignada || 'CUENTA_A'
  const configCuenta = CUENTAS_CONFIG[cuentaAsignada] || CUENTAS_CONFIG['CUENTA_A']

  function obtenerDatosTienda(tienda) {
    const prov = tienda.proveedor
    const datosProv = configCuenta[prov]
    if (!datosProv) return { ref: 'REFERENCIA_NO_DISPONIBLE', comision: 0 }
    
    // Mapear ID de tienda a clave de comisión
    const claveComision = tienda.id === 'walmart' ? 'walmart' 
      : tienda.id === 'seven' ? 'seven'
      : tienda.id === 'ahorro' ? 'ahorro'
      : tienda.id === 'soriana' ? 'soriana' : 'walmart'
    
    return {
      ref: datosProv.ref,
      comision: datosProv.comisiones[claveComision] || 0
    }
  }

  const datosTiendaActual = esTienda ? obtenerDatosTienda(opcionElegida) : null

  function elegirOpcion(opcion) {
    setOpcionElegida(opcion)
    setRefGenerada(false)
    setError('')
  }

  function generarReferencia() {
    setGenerandoRef(true)
    setTimeout(() => {
      setGenerandoRef(false)
      setRefGenerada(true)
    }, 1800)
  }

  async function subirComprobante(archivo) {
    if (!archivo) return
    setSubiendo(true)
    setError('')
    try {
      const dataUrl = await comprimirImagen(archivo)
      const res = await fetch('/.netlify/functions/notificar-comprobante', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          imagen: dataUrl,
          compraId: compra.id,
          monto: pagoInicial,
          tipo: 'pago_inicial'
        })
      })
      const data = await res.json()
      if (!res.ok || !data.ok) {
        setError('No pudimos subir tu comprobante. Intenta de nuevo.')
        setSubiendo(false)
        return
      }
      await supabase.from('comprobantes').insert({
        compra_id: compra.id,
        usuario_id: compra.usuario_id,
        imagen_url: data.imagenUrl || '',
        monto: pagoInicial,
        revisado: false
      })
      setSubiendo(false)
      setModalYaPague(true)
    } catch {
      setError('No pudimos subir tu comprobante. Intenta de nuevo.')
      setSubiendo(false)
    }
  }

  // Fecha de recolección/entrega asignada por admin
  const fechaDisponible = compra.fecha_disponible 
    ? new Date(compra.fecha_disponible).toLocaleDateString('es-MX', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })
    : null

  return (
    <Layout>
      <div className="max-w-2xl mx-auto px-4 py-8">
        <h1 className="text-2xl font-extrabold text-textoOscuro tracking-tight">Pago inicial</h1>
        <p className="text-sm text-gray-500 mt-1">Completa tu pago inicial para asegurar tu producto.</p>

        <motion.div
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          className="mt-5 bg-white rounded-2xl border border-gray-100 p-5 space-y-4"
        >
          <div className="flex justify-between items-center">
            <span className="text-sm text-gray-600">{compra.producto_nombre || compra.producto_id}</span>
            <span className="font-extrabold text-textoOscuro">{formatoMoneda(pagoInicial)}</span>
          </div>
          <p className="text-xs text-gray-500">Este es el 10% del precio total de tu compra.</p>

          {/* FECHA ASIGNADA POR ADMIN */}
          {fechaDisponible && (
            <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-3">
              <p className="text-xs font-bold text-emerald-800">
                📅 Tu producto estará disponible el: <span className="uppercase">{fechaDisponible}</span>
              </p>
            </div>
          )}

          <div className="border-t border-gray-100 pt-4">
            <p className="text-sm font-bold text-textoOscuro mb-3">Elige cómo pagarás</p>

            {/* OPCIÓN 1: BODEGA MERCALOGRO */}
            <motion.button
              whileHover={{ scale: 1.01 }}
              whileTap={{ scale: 0.99 }}
              onClick={() => elegirOpcion('bodega')}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl border text-left transition-colors mb-2 ${
                esBodega
                  ? 'border-principal bg-emerald-50'
                  : 'border-gray-200 hover:border-principal'
              }`}
            >
              <div className="w-8 h-8 rounded-full bg-principal text-white flex items-center justify-center shrink-0">
                <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
                  <path strokeLinecap="round" strokeLinejoin="round" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" />
                </svg>
              </div>
              <div>
                <p className="text-sm font-bold text-textoOscuro">Recoger y pagar en Bodega Mercalogro</p>
                <p className="text-xs text-gray-500 mt-0.5">Paga en efectivo o tarjeta al recoger. Sin envío.</p>
              </div>
            </motion.button>

            {/* OPCIÓN 2: TIENDAS FÍSICAS PARTICIPANTES */}
            <div className="mb-2">
              <p className="text-xs font-semibold text-gray-500 mb-2 ml-1">Pago en tiendas físicas participantes</p>
              <div className="grid sm:grid-cols-2 gap-2">
                {TIENDAS.map((t) => (
                  <motion.button
                    key={t.id}
                    whileHover={{ scale: 1.01 }}
                    whileTap={{ scale: 0.99 }}
                    onClick={() => elegirOpcion(t)}
                    className={`flex items-center gap-3 px-3 py-2.5 rounded-xl border text-left transition-colors ${
                      esTienda && opcionElegida?.id === t.id
                        ? 'border-principal bg-emerald-50'
                        : 'border-gray-200 hover:border-principal'
                    }`}
                  >
                    {t.logo && <img src={t.logo} alt={t.nombre} className="w-6 h-6 object-contain" />}
                    <span className="text-sm font-semibold text-textoOscuro">{t.nombre}</span>
                  </motion.button>
                ))}
              </div>
            </div>

            {/* OPCIÓN 3: TARJETA (BLOQUEADA HASTA SEGUNDA COMPRA) */}
            <motion.button
              whileHover={{ scale: 1.01 }}
              whileTap={{ scale: 0.99 }}
              onClick={() => elegirOpcion('tarjeta')}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl border text-left transition-colors ${
                esTarjeta
                  ? 'border-principal bg-emerald-50'
                  : 'border-gray-200 hover:border-principal'
              }`}
            >
              <div className="w-8 h-8 rounded-full bg-gray-200 text-gray-500 flex items-center justify-center shrink-0">
                <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
                  <path strokeLinecap="round" strokeLinejoin="round" d="M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z" />
                </svg>
              </div>
              <div>
                <p className="text-sm font-bold text-textoOscuro">Tarjeta de crédito o débito</p>
                <p className="text-xs text-gray-500 mt-0.5">Pago directo en línea.</p>
              </div>
            </motion.button>

            {/* MENSAJE DINÁMICO TARJETA BLOQUEADA */}
            <AnimatePresence>
              {esTarjeta && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  exit={{ opacity: 0, height: 0 }}
                  className="overflow-hidden"
                >
                  <div className="mt-3 bg-red-50 border border-red-200 rounded-xl p-3">
                    <p className="text-xs font-bold text-red-700">
                      Esta opción está disponible a partir de tu segunda compra aprobada.
                    </p>
                    <p className="text-[11px] text-red-600 mt-1">
                      Completa tu primera compra en bodega o tienda física para desbloquear pagos con tarjeta.
                    </p>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          {/* DETALLES BODEGA */}
          <AnimatePresence>
            {esBodega && (
              <motion.div
                initial={{ opacity: 0, y: 6 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -6 }}
                className="border-t border-gray-100 pt-4 space-y-2"
              >
                <p className="text-sm font-bold text-textoOscuro">Instrucciones para bodega</p>
                <div className="bg-fondoClaro rounded-xl p-3 space-y-1">
                  <p className="text-xs text-gray-600 font-semibold">Dirección:</p>
                  <p className="text-sm text-textoOscuro leading-relaxed">{DIRECCION_BODEGA}</p>
                </div>
                <p className="text-xs text-gray-600">
                  Monto a pagar: <strong>{formatoMoneda(pagoInicial)}</strong>
                </p>
                <p className="text-xs text-gray-600">
                  Aceptamos <strong>efectivo</strong> y <strong>tarjeta de crédito/débito</strong> en el punto de venta.
                </p>
                <p className="text-[11px] text-gray-500">
                  Al llegar, dirígete a la Zona de Servicios / Recepción Logística y menciona que vienes a recoger un pedido de Mercalogro. Proporciona tu nombre o número de compra.
                </p>
              </motion.div>
            )}
          </AnimatePresence>

          {/* DETALLES TIENDA + GENERACIÓN DE REFERENCIA */}
          <AnimatePresence>
            {esTienda && (
              <motion.div
                initial={{ opacity: 0, y: 6 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -6 }}
                className="border-t border-gray-100 pt-4 space-y-2"
              >
                {!refGenerada && !generandoRef && (
                  <motion.button
                    whileHover={{ scale: 1.01 }}
                    whileTap={{ scale: 0.99 }}
                    onClick={generarReferencia}
                    className="w-full bg-principal text-white font-bold py-3 rounded-xl hover:bg-emerald-800 transition-colors"
                  >
                    Generar número de referencia
                  </motion.button>
                )}

                {generandoRef && (
                  <div className="bg-fondoClaro rounded-xl p-6 text-center space-y-3">
                    <div className="w-8 h-8 mx-auto border-4 border-principal border-t-transparent rounded-full animate-spin" />
                    <p className="text-sm font-semibold text-textoOscuro">Espera, estamos generando tu número de referencia…</p>
                  </div>
                )}

                {refGenerada && !generandoRef && datosTiendaActual && (
                  <>
                    <p className="text-sm font-bold text-textoOscuro">Instrucciones</p>
                    <p className="text-xs text-gray-600">
                      Dile al cajero que el proveedor de pago es <strong>{opcionElegida.proveedor}</strong>.
                    </p>
                    <p className="text-xs text-gray-600">
                      Monto a pagar: <strong>{formatoMoneda(pagoInicial)}</strong> + comisión de tienda de ${datosTiendaActual.comision} MXN.
                    </p>
                    <div className="bg-fondoClaro rounded-xl p-3">
                      <p className="text-[11px] text-gray-500">Tu número de referencia personal:</p>
                      <p className="text-lg font-extrabold text-textoOscuro tracking-wide">{datosTiendaActual.ref}</p>
                    </div>
                    <p className="text-[11px] text-gray-500">
                      Este número está ligado a ti. Guárdalo o toma captura. Deberás proporcionarlo al cajero junto con las instrucciones de pago.
                    </p>
                  </>
                )}
              </motion.div>
            )}
          </AnimatePresence>

          {error && <p className="text-xs text-red-600">{error}</p>}

          {/* BOTÓN YA PAGUÉ (solo para bodega o tienda con ref generada) */}
          {(esBodega || (esTienda && refGenerada)) && (
            <motion.button
              whileHover={{ scale: 1.01 }}
              whileTap={{ scale: 0.99 }}
              onClick={() => setModalYaPague(true)}
              className="w-full bg-principal text-white font-bold py-3 rounded-xl hover:bg-emerald-800 transition-colors"
            >
              Ya pagué
            </motion.button>
          )}
        </motion.div>
      </div>

      {/* MODAL COMPROBANTE */}
      {modalYaPague && (
        <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4">
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white rounded-2xl shadow-2xl w-full max-w-sm p-6 text-center"
          >
            <h2 className="text-lg font-extrabold text-textoOscuro">Ya realicé mi pago</h2>
            <p className="text-sm text-gray-600 mt-2">
              No tienes que hacer nada más. En unos instantes el sistema procesará tu compra.
            </p>
            <p className="text-xs text-gray-500 mt-2">
              Si deseas subir tu comprobante, puedes hacerlo aquí. Es opcional y solo sirve como respaldo.
            </p>
            <label className="mt-4 block">
              <span className="inline-block bg-fondoClaro text-textoOscuro text-sm font-semibold px-4 py-2 rounded-xl cursor-pointer hover:bg-gray-200 transition-colors">
                {subiendo ? 'Subiendo…' : 'Subir comprobante'}
              </span>
              <input
                type="file"
                accept="image/*"
                capture="environment"
                className="hidden"
                onChange={(e) => subirComprobante(e.target.files?.[0])}
              />
            </label>
            <button
              onClick={() => { setModalYaPague(false); navigate('/mi-cuenta') }}
              className="mt-4 w-full text-sm text-principal font-semibold hover:underline"
            >
              Cerrar
            </button>
          </motion.div>
        </div>
      )}

      <WidgetAtencion />
    </Layout>
  )
}

async function comprimirImagen(archivo) {
  return new Promise((resolve) => {
    const img = new Image()
    const url = URL.createObjectURL(archivo)
    img.onload = () => {
      const maxAncho = 1200
      const escala = Math.min(1, maxAncho / img.width)
      const canvas = document.createElement('canvas')
      canvas.width = img.width * escala
      canvas.height = img.height * escala
      canvas.getContext('2d').drawImage(img, 0, 0, canvas.width, canvas.height)
      URL.revokeObjectURL(url)
      resolve(canvas.toDataURL('image/jpeg', 0.75))
    }
    img.src = url
  })
}