import { useState } from 'react'
import { useParams, Link, useNavigate } from 'react-router-dom'
import { motion, AnimatePresence } from 'framer-motion'
import Layout from '../components/Layout.jsx'
import WidgetAtencion from '../components/WidgetAtencion.jsx'
import BannerSolicitud from '../components/BannerSolicitud.jsx'
import { productosPiloto } from '../data/productos.js'

function formatoMoneda(n) {
  return n.toLocaleString('es-MX', { style: 'currency', currency: 'MXN', maximumFractionDigits: 0 })
}

export default function Producto() {
  const { id } = useParams()
  const navigate = useNavigate()
  const producto = productosPiloto.find((p) => p.id === id)
  const [modal, setModal] = useState(false)

  if (!producto) {
    return (
      <Layout>
        <div className="max-w-6xl mx-auto px-4 py-20 text-center">
          <p className="text-gray-500">Producto no encontrado.</p>
          <Link to="/" className="mt-4 inline-block text-principal font-semibold hover:underline">
            Volver a la tienda
          </Link>
        </div>
      </Layout>
    )
  }

  const {
    nombre,
    imagen,
    descripcion,
    precioContado,
    precioAnterior,
    precioPlazos,
    stockBajo,
    altaDemanda
  } = producto

  const pagoMensual = Math.round(precioPlazos / 6)
  const pagoInicial = Math.round(precioPlazos * 0.1)

  function elegir(modo) {
    setModal(false)
    if (modo === 'contado') {
      navigate(`/checkout-contado?producto=${id}`)
    } else {
      navigate(`/solicitud/intro?producto=${id}`)
    }
  }

  return (
    <Layout>
      <div className="max-w-6xl mx-auto px-4 py-8">
        <div className="grid md:grid-cols-2 gap-8">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.25 }}
            className="bg-white rounded-2xl border border-gray-100 p-6 flex items-center justify-center aspect-square"
          >
            {imagen ? (
              <img src={imagen} alt={nombre} className="max-h-full object-contain" />
            ) : (
              <span className="text-gray-300 text-sm">Sin imagen</span>
            )}
          </motion.div>

          <div>
            <div className="flex gap-2 mb-3">
              {altaDemanda && (
                <span className="bg-acento text-white text-[10px] font-bold px-2 py-1 rounded-full">
                  ALTA DEMANDA
                </span>
              )}
              {stockBajo && (
                <span className="bg-red-600 text-white text-[10px] font-bold px-2 py-1 rounded-full">
                  SE AGOTA
                </span>
              )}
            </div>

            <h1 className="text-2xl md:text-3xl font-extrabold text-textoOscuro tracking-tight">
              {nombre}
            </h1>
            <p className="text-sm text-gray-500 mt-2">{descripcion}</p>

            <div className="mt-6 bg-white rounded-2xl border border-gray-100 p-5">
              {precioAnterior && precioAnterior > precioContado && (
                <p className="text-sm text-gray-400 line-through">{formatoMoneda(precioAnterior)}</p>
              )}
              <p className="text-3xl font-extrabold text-textoOscuro">{formatoMoneda(precioContado)}</p>
              <p className="text-xs text-gray-500">Precio de contado</p>

              <div className="mt-4 pt-4 border-t border-gray-100">
                <p className="text-sm text-textoOscuro">
                  o <strong>6 pagos de {formatoMoneda(pagoMensual)}</strong> al mes
                </p>
                <p className="text-xs text-gray-500 mt-1">
                  Pago inicial del 10%: {formatoMoneda(pagoInicial)}
                </p>
              </div>

              <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={() => setModal(true)}
                className="mt-5 w-full bg-principal text-white font-bold py-3 rounded-xl hover:bg-emerald-800 transition-colors"
              >
                Comprar
              </motion.button>
            </div>
          </div>
        </div>
      </div>

      <AnimatePresence>
        {modal && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4"
            onClick={() => setModal(false)}
          >
            <motion.div
              initial={{ opacity: 0, y: 16, scale: 0.97 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 16, scale: 0.97 }}
              transition={{ duration: 0.2, ease: 'easeOut' }}
              onClick={(e) => e.stopPropagation()}
              className="bg-white rounded-2xl shadow-2xl w-full max-w-md p-6"
            >
              <h2 className="text-lg font-extrabold text-textoOscuro">Elige cómo pagar</h2>
              <p className="text-sm text-gray-500 mt-1">Selecciona la modalidad de tu compra.</p>

              <div className="mt-5 space-y-3">
                <button
                  onClick={() => elegir('contado')}
                  className="w-full text-left border border-gray-200 rounded-xl p-4 hover:border-principal transition-colors"
                >
                  <p className="font-bold text-textoOscuro">Contado</p>
                  <p className="text-xs text-gray-500 mt-1">
                    Pago contraentrega. Envío gratis a partir de $600.
                  </p>
                </button>

                <button
                  onClick={() => elegir('plazos')}
                  className="w-full text-left border border-gray-200 rounded-xl p-4 hover:border-principal transition-colors"
                >
                  <p className="font-bold text-textoOscuro">A plazos</p>
                  <p className="text-xs text-gray-500 mt-1">
                    6 pagos mensuales. Requiere pago inicial del 10%.
                  </p>
                </button>
              </div>

              <button
                onClick={() => setModal(false)}
                className="mt-4 w-full text-sm text-gray-500 hover:text-gray-800"
              >
                Cancelar
              </button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      <WidgetAtencion />
      <BannerSolicitud />
    </Layout>
  )
}