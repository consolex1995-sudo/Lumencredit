import { useEffect, useState } from 'react'
import { motion } from 'framer-motion'
import { supabase } from '../lib/supabase.js'

function formatoFecha(f) {
  if (!f) return '—'
  return new Date(f).toLocaleString('es-MX', {
    day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit'
  })
}

export default function AdminComprobantes() {
  const [comprobantes, setComprobantes] = useState([])
  const [cargando, setCargando] = useState(true)
  const [error, setError] = useState('')
  const [ampliado, setAmpliado] = useState(null)

  async function cargar() {
    setCargando(true)
    const { data, error: err } = await supabase
      .from('comprobantes')
      .select('*')
      .order('creado_en', { ascending: false })
      .limit(100)

    if (err) setError('No pudimos cargar los comprobantes.')
    else setComprobantes(data || [])
    setCargando(false)
  }

  useEffect(() => {
    cargar()
  }, [])

  async function marcarRevisado(id) {
    setError('')
    const { error: err } = await supabase
      .from('comprobantes')
      .update({ revisado: true })
      .eq('id', id)

    if (err) {
      setError('No pudimos actualizar el comprobante.')
      return
    }
    setComprobantes((c) => c.map((x) => (x.id === id ? { ...x, revisado: true } : x)))
  }

  if (cargando) {
    return (
      <div className="bg-white rounded-2xl border border-gray-100 p-8 text-center">
        <div className="w-8 h-8 mx-auto border-4 border-principal border-t-transparent rounded-full animate-spin" />
      </div>
    )
  }

  return (
    <div className="space-y-3">
      {error && <p className="text-xs text-red-600">{error}</p>}

      {comprobantes.length === 0 ? (
        <div className="bg-white rounded-2xl border border-gray-100 p-8 text-center">
          <p className="text-sm text-gray-500">No hay comprobantes recibidos.</p>
        </div>
      ) : (
        comprobantes.map((c) => (
          <motion.div
            key={c.id}
            initial={{ opacity: 0, y: 6 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white rounded-2xl border border-gray-100 p-4 flex flex-col sm:flex-row gap-3 items-start"
          >
            <button
              onClick={() => setAmpliado(c.imagen_url)}
              className="shrink-0 w-20 h-20 rounded-xl overflow-hidden border border-gray-200 bg-gray-50"
            >
              {c.imagen_url ? (
                <img src={c.imagen_url} alt="Comprobante" className="w-full h-full object-cover" />
              ) : (
                <span className="text-[10px] text-gray-400 flex items-center justify-center h-full">Sin imagen</span>
              )}
            </button>

            <div className="flex-1">
              <p className="text-sm font-bold text-textoOscuro">
                Compra: {c.compra_id?.slice(0, 8) || '—'}
              </p>
              <p className="text-xs text-gray-500 mt-0.5">
                Recibido: {formatoFecha(c.creado_en)}
              </p>
              {c.monto && (
                <p className="text-xs text-gray-500">Monto declarado: ${c.monto}</p>
              )}
              <div className="mt-2 flex items-center gap-2">
                <span className={`text-[11px] font-bold px-2 py-1 rounded-full ${
                  c.revisado ? 'bg-emerald-100 text-principal' : 'bg-amber-100 text-amber-700'
                }`}>
                  {c.revisado ? 'Revisado' : 'Pendiente'}
                </span>
                {!c.revisado && (
                  <button
                    onClick={() => marcarRevisado(c.id)}
                    className="text-xs font-semibold text-principal hover:underline"
                  >
                    Marcar como revisado
                  </button>
                )}
              </div>
            </div>
          </motion.div>
        ))
      )}

      {ampliado && (
        <div
          onClick={() => setAmpliado(null)}
          className="fixed inset-0 z-50 bg-black/70 flex items-center justify-center p-4"
        >
          <img
            src={ampliado}
            alt="Comprobante ampliado"
            className="max-h-[90vh] max-w-full rounded-xl"
          />
        </div>
      )}
    </div>
  )
}