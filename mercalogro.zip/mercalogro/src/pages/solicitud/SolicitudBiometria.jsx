import { useEffect, useRef, useState } from 'react'
import { useSearchParams, useNavigate } from 'react-router-dom'
import { motion, AnimatePresence } from 'framer-motion'
import * as faceapi from 'face-api.js'
import Layout from '../../components/Layout.jsx'
import WidgetAtencion from '../../components/WidgetAtencion.jsx'

const MODELOS_URL = 'https://cdn.jsdelivr.net/npm/@vladmandic/face-api/model/'

export default function SolicitudBiometria() {
  const [params] = useSearchParams()
  const navigate = useNavigate()

  const [fase, setFase] = useState('intro')
  const [modelosListos, setModelosListos] = useState(false)
  const [error, setError] = useState('')
  const [fotoIne, setFotoIne] = useState(null)
  const [fotoSelfie, setFotoSelfie] = useState(null)
  const [resultado, setResultado] = useState(null)

  const videoRef = useRef(null)
  const canvasRef = useRef(null)
  const streamRef = useRef(null)
  const detectorRef = useRef(null)

  useEffect(() => {
    let activo = true
    async function cargar() {
      try {
        await faceapi.nets.tinyFaceDetector.loadFromUri(MODELOS_URL)
        await faceapi.nets.faceLandmark68Net.loadFromUri(MODELOS_URL)
        await faceapi.nets.faceRecognitionNet.loadFromUri(MODELOS_URL)
        if (activo) setModelosListos(true)
      } catch {
        if (activo) setError('No pudimos cargar el verificador. Revisa tu conexión.')
      }
    }
    cargar()
    return () => {
      activo = false
    }
  }, [])

  useEffect(() => {
    return () => {
      detenerCamara()
    }
  }, [])

  function detenerCamara() {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((t) => t.stop())
      streamRef.current = null
    }
  }

  async function abrirCamara() {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'user', width: { ideal: 1280 }, height: { ideal: 720 } },
        audio: false
      })
      streamRef.current = stream
      if (videoRef.current) {
        videoRef.current.srcObject = stream
        await videoRef.current.play()
      }
      iniciarDeteccion()
    } catch {
      setError('Necesitamos acceso a tu cámara para continuar.')
    }
  }

  function iniciarDeteccion() {
    if (detectorRef.current) clearInterval(detectorRef.current)
    detectorRef.current = setInterval(async () => {
      if (!videoRef.current) return
      const det = await faceapi.detectSingleFace(
        videoRef.current,
        new faceapi.TinyFaceDetectorOptions({ inputSize: 320, scoreThreshold: 0.5 })
      )
      if (det && fase === 'captura-ine') capturar('ine')
      if (det && fase === 'captura-selfie') capturar('selfie')
    }, 900)
  }

  async function capturar(tipo) {
    if (!videoRef.current || !canvasRef.current) return
    clearInterval(detectorRef.current)
    const video = videoRef.current
    const canvas = canvasRef.current
    canvas.width = video.videoWidth
    canvas.height = video.videoHeight
    canvas.getContext('2d').drawImage(video, 0, 0, canvas.width, canvas.height)
    const dataUrl = canvas.toDataURL('image/jpeg', 0.85)

    if (tipo === 'ine') {
      setFotoIne(dataUrl)
      detenerCamara()
      setFase('intro-selfie')
    } else {
      setFotoSelfie(dataUrl)
      detenerCamara()
      comparar(dataUrl)
    }
  }

  async function comparar(selfieDataUrl) {
    setFase('comparando')
    try {
      const imgIne = await faceapi.fetchImage(fotoIne)
      const imgSelfie = await faceapi.fetchImage(selfieDataUrl)

      const descIne = await faceapi
        .detectSingleFace(imgIne, new faceapi.TinyFaceDetectorOptions())
        .withFaceLandmarks()
        .withFaceDescriptor()

      const descSelfie = await faceapi
        .detectSingleFace(imgSelfie, new faceapi.TinyFaceDetectorOptions())
        .withFaceLandmarks()
        .withFaceDescriptor()

      if (!descIne || !descSelfie) {
        setResultado({ coincide: false, distancia: null })
        setFase('resultado')
        return
      }

      const distancia = faceapi.euclideanDistance(descIne.descriptor, descSelfie.descriptor)
      const coincide = distancia < 0.55
      setResultado({ coincide, distancia })
      setFase('resultado')
    } catch {
      setResultado({ coincide: false, distancia: null })
      setFase('resultado')
    }
  }

  function reintentar() {
    setFotoIne(null)
    setFotoSelfie(null)
    setResultado(null)
    setError('')
    setFase('captura-ine')
    abrirCamara()
  }

  function continuarAuditoria() {
    navigate(`/solicitud/auditoria?producto=${params.get('producto') || ''}`)
  }

  return (
    <Layout>
      <div className="max-w-xl mx-auto px-4 py-10">
        <canvas ref={canvasRef} className="hidden" />

        <AnimatePresence mode="wait">
          {fase === 'intro' && (
            <motion.div
              key="intro"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="bg-white rounded-2xl border border-gray-100 p-8 text-center"
            >
              <h1 className="text-xl font-extrabold text-textoOscuro">
                Ahora vamos a verificar tu identidad
              </h1>
              <div className="mt-6 flex flex-col items-center">
                <motion.p
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 0.3 }}
                  className="text-2xl font-extrabold text-blue-700 tracking-tight"
                >
                  VerifyID
                </motion.p>
                <p className="text-xs text-blue-600 font-semibold">by SoftLabs</p>
                <div className="flex gap-1.5 mt-4">
                  {[0, 1, 2].map((i) => (
                    <motion.span
                      key={i}
                      className="w-2.5 h-2.5 rounded-full bg-blue-600"
                      animate={{ opacity: [0.2, 1, 0.2] }}
                      transition={{ duration: 0.9, repeat: Infinity, delay: i * 0.25 }}
                    />
                  ))}
                </div>
              </div>

              {error && <p className="mt-4 text-xs text-red-600">{error}</p>}

              <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                disabled={!modelosListos}
                onClick={() => {
                  setFase('captura-ine')
                  abrirCamara()
                }}
                className="mt-6 w-full bg-principal text-white font-bold py-3 rounded-xl hover:bg-emerald-800 transition-colors disabled:opacity-50"
              >
                {modelosListos ? 'Continuar' : 'Cargando verificador…'}
              </motion.button>
            </motion.div>
          )}

          {(fase === 'captura-ine' || fase === 'captura-selfie') && (
            <motion.div
              key={fase}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="bg-white rounded-2xl border border-gray-100 p-4"
            >
              <h2 className="text-center text-sm font-bold text-textoOscuro mb-1">
                {fase === 'captura-ine' ? 'Coloca el frente de tu INE dentro del recuadro' : 'Coloca tu rostro dentro del óvalo'}
              </h2>
              <p className="text-center text-xs text-gray-500 mb-3">
                La captura es automática cuando el sistema lo detecte.
              </p>

              <div className="relative bg-white rounded-2xl overflow-hidden">
                <video ref={videoRef} muted playsInline className="w-full h-auto" />
                {fase === 'captura-ine' ? (
                  <div className="absolute inset-6 border-4 border-dashed border-principal/70 rounded-2xl pointer-events-none" />
                ) : (
                  <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                    <div className="w-48 h-64 border-4 border-principal/70 rounded-full" />
                  </div>
                )}
              </div>

              {error && <p className="mt-3 text-xs text-red-600">{error}</p>}
            </motion.div>
          )}

          {fase === 'intro-selfie' && (
            <motion.div
              key="intro-selfie"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="bg-white rounded-2xl border border-gray-100 p-8 text-center"
            >
              <h2 className="text-xl font-extrabold text-textoOscuro">Ahora tómate una selfie</h2>
              <p className="text-sm text-gray-600 mt-2">Sin lentes ni gorra, con buena iluminación.</p>

              <div className="mt-6 flex justify-center">
                <motion.div
                  initial={{ y: 0 }}
                  animate={{ y: [-2, 2, -2] }}
                  transition={{ duration: 2, repeat: Infinity }}
                  className="w-24 h-24 rounded-full bg-emerald-100 flex items-center justify-center text-4xl"
                >
                  🙂
                </motion.div>
              </div>

              <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={() => {
                  setFase('captura-selfie')
                  abrirCamara()
                }}
                className="mt-6 w-full bg-principal text-white font-bold py-3 rounded-xl hover:bg-emerald-800 transition-colors"
              >
                Continuar
              </motion.button>
            </motion.div>
          )}

          {fase === 'comparando' && (
            <motion.div
              key="comparando"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="bg-white rounded-2xl border border-gray-100 p-10 text-center"
            >
              <div className="w-10 h-10 mx-auto border-4 border-principal border-t-transparent rounded-full animate-spin" />
              <p className="mt-4 text-sm text-gray-600">Verificando identidad…</p>
            </motion.div>
          )}

          {fase === 'resultado' && (
            <motion.div
              key="resultado"
              initial={{ opacity: 0, scale: 0.97 }}
              animate={{ opacity: 1, scale: 1 }}
              className="bg-white rounded-2xl border border-gray-100 p-8 text-center"
            >
              {resultado?.coincide ? (
                <>
                  <div className="w-16 h-16 mx-auto rounded-full bg-emerald-100 flex items-center justify-center">
                    <svg className="w-8 h-8 text-principal" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
                      <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
                    </svg>
                  </div>
                  <p className="mt-4 text-sm text-gray-600">Identidad verificada.</p>
                  <motion.button
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    onClick={continuarAuditoria}
                    className="mt-6 w-full bg-principal text-white font-bold py-3 rounded-xl hover:bg-emerald-800 transition-colors"
                  >
                    Continuar
                  </motion.button>
                </>
              ) : (
                <>
                  <div className="w-16 h-16 mx-auto rounded-full bg-red-100 flex items-center justify-center">
                    <svg className="w-8 h-8 text-red-600" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
                      <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
                    </svg>
                  </div>
                  <p className="mt-4 text-sm text-gray-600">No pudimos verificar tu identidad, intenta de nuevo.</p>
                  <motion.button
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    onClick={reintentar}
                    className="mt-6 w-full bg-principal text-white font-bold py-3 rounded-xl hover:bg-emerald-800 transition-colors"
                  >
                    Intentar de nuevo
                  </motion.button>
                </>
              )}
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      <WidgetAtencion />
    </Layout>
  )
}