import { useState } from 'react'
import { useSearchParams, useNavigate } from 'react-router-dom'
import { motion } from 'framer-motion'
import Layout from '../../components/Layout.jsx'
import WidgetAtencion from '../../components/WidgetAtencion.jsx'
import { supabase } from '../../lib/supabase.js'

const CLAVE_BORRADOR = 'mercalogro_solicitud_datos_personales'

const camposIniciales = {
  nombre: '',
  apellidoPaterno: '',
  apellidoMaterno: '',
  curp: '',
  rfc: '',
  homoclave: '',
  fechaNacimiento: '',
  telefono: '',
  correo: ''
}

export default function SolicitudDatosPersonales() {
  const [params] = useSearchParams()
  const navigate = useNavigate()

  const [form, setForm] = useState(() => {
    try {
      const raw = localStorage.getItem(CLAVE_BORRADOR)
      return raw ? { ...camposIniciales, ...JSON.parse(raw) } : camposIniciales
    } catch {
      return camposIniciales
    }
  })
  const [error, setError] = useState('')
  const [validando, setValidando] = useState(false)

  function cambiar(campo, valor) {
    setForm((f) => ({ ...f, [campo]: valor }))
  }

  function limpiarEspacios(campo) {
    setForm((f) => ({ ...f, [campo]: (f[campo] || '').trim().replace(/\s+/g, ' ') }))
  }

  async function continuar(e) {
    e.preventDefault()
    setError('')

    const obligatorios = [
      ['nombre', 'El nombre es obligatorio.'],
      ['apellidoPaterno', 'El apellido paterno es obligatorio.'],
      ['apellidoMaterno', 'El apellido materno es obligatorio.'],
      ['curp', 'La CURP es obligatoria.'],
      ['rfc', 'El RFC es obligatorio.'],
      ['fechaNacimiento', 'La fecha de nacimiento es obligatoria.'],
      ['telefono', 'El teléfono es obligatorio.'],
      ['correo', 'El correo es obligatorio.']
    ]

    for (const [campo, mensaje] of obligatorios) {
      if (!form[campo]?.trim()) {
        setError(mensaje)
        return
      }
    }

    if (form.curp.length !== 18) {
      setError('La CURP debe tener 18 caracteres.')
      return
    }

    const tel = form.telefono.replace(/\D/g, '')
    if (tel.length !== 10) {
      setError('El teléfono debe tener 10 dígitos.')
      return
    }

    const correoValido = /^[^\s@]+@[^\s@]+$/.test(form.correo.trim())
    if (!correoValido) {
      setError('El correo no tiene un formato válido.')
      return
    }

    setValidando(true)

    const { data: existeCurp } = await supabase
      .from('perfiles')
      .select('id')
      .eq('curp', form.curp)
      .maybeSingle()

    if (existeCurp) {
      setValidando(false)
      setError('CURP ya registrada.')
      return
    }

    const { data: existeCorreo } = await supabase
      .from('perfiles')
      .select('id')
      .eq('correo', form.correo.trim().toLowerCase())
      .maybeSingle()

    if (existeCorreo) {
      setValidando(false)
      setError('Correo ya registrado.')
      return
    }

    localStorage.setItem(CLAVE_BORRADOR, JSON.stringify(form))
    setValidando(false)
    navigate(`/solicitud/datos-laborales?producto=${params.get('producto') || ''}`)
  }

  return (
    <Layout>
      <div className="max-w-2xl mx-auto px-4 py-10">
        <motion.form
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3 }}
          onSubmit={continuar}
          className="bg-white rounded-2xl border border-gray-100 p-6 md:p-8 space-y-4"
        >
          <h1 className="text-2xl font-extrabold text-textoOscuro tracking-tight">Datos personales</h1>

          <div className="grid sm:grid-cols-3 gap-3">
            <Campo label="Nombre(s)" valor={form.nombre} cambiar={(v) => cambiar('nombre', v)} onBlur={() => limpiarEspacios('nombre')} />
            <Campo label="Apellido paterno" valor={form.apellidoPaterno} cambiar={(v) => cambiar('apellidoPaterno', v)} onBlur={() => limpiarEspacios('apellidoPaterno')} />
            <Campo label="Apellido materno" valor={form.apellidoMaterno} cambiar={(v) => cambiar('apellidoMaterno', v)} onBlur={() => limpiarEspacios('apellidoMaterno')} />
          </div>

          <Campo
            label="CURP"
            valor={form.curp}
            cambiar={(v) => cambiar('curp', v.toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 18))}
            maxLength={18}
          />

          <div className="grid sm:grid-cols-2 gap-3">
            <Campo
              label="RFC"
              valor={form.rfc}
              cambiar={(v) => cambiar('rfc', v.toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 10))}
              maxLength={10}
            />
            <Campo
              label="Homoclave (opcional)"
              valor={form.homoclave}
              cambiar={(v) => cambiar('homoclave', v.toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 3))}
              maxLength={3}
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-gray-600 mb-1">Fecha de nacimiento</label>
            <input
              type="date"
              value={form.fechaNacimiento}
              onChange={(e) => cambiar('fechaNacimiento', e.target.value)}
              className="w-full border border-gray-200 rounded-xl px-3 py-2 text-sm outline-none focus:border-principal"
            />
          </div>

          <Campo
            label="Teléfono"
            valor={form.telefono}
            cambiar={(v) => cambiar('telefono', v.replace(/\D/g, '').slice(0, 10))}
            inputMode="numeric"
            maxLength={10}
          />

          <Campo
            label="Correo electrónico"
            valor={form.correo}
            cambiar={(v) => cambiar('correo', v)}
            onBlur={() => limpiarEspacios('correo')}
            type="email"
          />

          {error && <p className="text-xs text-red-600">{error}</p>}

          <motion.button
            whileHover={{ scale: 1.01 }}
            whileTap={{ scale: 0.99 }}
            type="submit"
            disabled={validando}
            className="w-full bg-principal text-white font-bold py-3 rounded-xl hover:bg-emerald-800 transition-colors disabled:opacity-60"
          >
            {validando ? 'Validando…' : 'Continuar'}
          </motion.button>
        </motion.form>
      </div>

      <WidgetAtencion />
    </Layout>
  )
}

function Campo({ label, valor, cambiar, onBlur, inputMode, maxLength, type = 'text' }) {
  return (
    <div>
      <label className="block text-xs font-semibold text-gray-600 mb-1">{label}</label>
      <input
        type={type}
        value={valor}
        inputMode={inputMode}
        maxLength={maxLength}
        onChange={(e) => cambiar(e.target.value)}
        onBlur={onBlur}
        className="w-full border border-gray-200 rounded-xl px-3 py-2 text-sm outline-none focus:border-principal"
      />
    </div>
  )
}