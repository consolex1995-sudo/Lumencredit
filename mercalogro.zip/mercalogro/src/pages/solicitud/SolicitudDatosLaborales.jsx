import { useState } from 'react'
import { useSearchParams, useNavigate } from 'react-router-dom'
import { motion } from 'framer-motion'
import Layout from '../../components/Layout.jsx'
import WidgetAtencion from '../../components/WidgetAtencion.jsx'

const CLAVE_BORRADOR = 'mercalogro_solicitud_datos_laborales'

const RANGOS_INGRESOS = [
  { id: '5-10', texto: '$5,000 – $10,000' },
  { id: '10-20', texto: '$10,001 – $20,000' },
  { id: '20-30', texto: '$20,001 – $30,000' },
  { id: '30-50', texto: '$30,001 – $50,000' },
  { id: '50-100', texto: '$50,001 – $100,000' }
]

const ANTIGUEDADES = [
  { id: 'menos-1', texto: 'Menos de 1 año' },
  { id: '1-3', texto: '1 a 3 años' },
  { id: 'mas-3', texto: 'Más de 3 años' }
]

const PERFILES = [
  { id: 'malo', texto: 'Malo' },
  { id: 'regular', texto: 'Regular' },
  { id: 'bueno', texto: 'Bueno' }
]

const inicial = {
  ocupacion: '',
  ingresos: '',
  antiguedad: '',
  perfil: '',
  creditosActivos: 1
}

export default function SolicitudDatosLaborales() {
  const [params] = useSearchParams()
  const navigate = useNavigate()

  const [form, setForm] = useState(() => {
    try {
      const raw = localStorage.getItem(CLAVE_BORRADOR)
      return raw ? { ...inicial, ...JSON.parse(raw) } : inicial
    } catch {
      return inicial
    }
  })
  const [error, setError] = useState('')

  function cambiar(campo, valor) {
    setForm((f) => ({ ...f, [campo]: valor }))
  }

  function continuar(e) {
    e.preventDefault()
    setError('')

    if (!form.ocupacion.trim()) {
      setError('La ocupación es obligatoria.')
      return
    }
    if (!form.ingresos) {
      setError('Selecciona un rango de ingresos.')
      return
    }
    if (!form.antiguedad) {
      setError('Selecciona tu antigüedad en el empleo.')
      return
    }
    if (!form.perfil) {
      setError('Indica cómo consideras tu perfil crediticio.')
      return
    }

    localStorage.setItem(CLAVE_BORRADOR, JSON.stringify(form))
    navigate(`/solicitud/biometria?producto=${params.get('producto') || ''}`)
  }

  return (
    <Layout>
      <div className="max-w-2xl mx-auto px-4 py-10">
        <motion.form
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3 }}
          onSubmit={continuar}
          className="bg-white rounded-2xl border border-gray-100 p-6 md:p-8 space-y-5"
        >
          <h1 className="text-2xl font-extrabold text-textoOscuro tracking-tight">Datos laborales</h1>

          <div>
            <label className="block text-xs font-semibold text-gray-600 mb-1">Ocupación</label>
            <input
              type="text"
              value={form.ocupacion}
              onChange={(e) => cambiar('ocupacion', e.target.value)}
              onBlur={() => cambiar('ocupacion', form.ocupacion.trim().replace(/\s+/g, ' '))}
              className="w-full border border-gray-200 rounded-xl px-3 py-2 text-sm outline-none focus:border-principal"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-gray-600 mb-1">Ingresos mensuales</label>
            <div className="grid sm:grid-cols-2 gap-2">
              {RANGOS_INGRESOS.map((r) => (
                <button
                  type="button"
                  key={r.id}
                  onClick={() => cambiar('ingresos', r.id)}
                  className={`text-left px-3 py-2 rounded-xl border text-sm transition-colors ${
                    form.ingresos === r.id
                      ? 'border-principal bg-emerald-50 text-textoOscuro font-semibold'
                      : 'border-gray-200 hover:border-principal text-gray-600'
                  }`}
                >
                  {r.texto}
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-gray-600 mb-1">Antigüedad en el empleo</label>
            <div className="grid sm:grid-cols-3 gap-2">
              {ANTIGUEDADES.map((a) => (
                <button
                  type="button"
                  key={a.id}
                  onClick={() => cambiar('antiguedad', a.id)}
                  className={`px-3 py-2 rounded-xl border text-sm transition-colors ${
                    form.antiguedad === a.id
                      ? 'border-principal bg-emerald-50 text-textoOscuro font-semibold'
                      : 'border-gray-200 hover:border-principal text-gray-600'
                  }`}
                >
                  {a.texto}
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-gray-600 mb-1">
              ¿Cómo consideras tu perfil crediticio?
            </label>
            <div className="grid grid-cols-3 gap-2">
              {PERFILES.map((p) => (
                <button
                  type="button"
                  key={p.id}
                  onClick={() => cambiar('perfil', p.id)}
                  className={`px-3 py-2 rounded-xl border text-sm transition-colors ${
                    form.perfil === p.id
                      ? 'border-principal bg-emerald-50 text-textoOscuro font-semibold'
                      : 'border-gray-200 hover:border-principal text-gray-600'
                  }`}
                >
                  {p.texto}
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-gray-600 mb-2">
              Número de créditos activos: <span className="text-principal font-bold">{form.creditosActivos}</span>
            </label>
            <input
              type="range"
              min={1}
              max={10}
              step={1}
              value={form.creditosActivos}
              onChange={(e) => cambiar('creditosActivos', Number(e.target.value))}
              className="w-full accent-principal"
            />
            <div className="flex justify-between text-[10px] text-gray-400 mt-1">
              <span>1</span>
              <span>10</span>
            </div>
          </div>

          {error && <p className="text-xs text-red-600">{error}</p>}

          <motion.button
            whileHover={{ scale: 1.01 }}
            whileTap={{ scale: 0.99 }}
            type="submit"
            className="w-full bg-principal text-white font-bold py-3 rounded-xl hover:bg-emerald-800 transition-colors"
          >
            Continuar
          </motion.button>
        </motion.form>
      </div>

      <WidgetAtencion />
    </Layout>
  )
}