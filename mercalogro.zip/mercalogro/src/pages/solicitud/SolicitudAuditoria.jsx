import { useEffect } from 'react'
import { useSearchParams, useNavigate } from 'react-router-dom'
import { motion } from 'framer-motion'
import Lottie from 'lottie-react'
import Layout from '../../components/Layout.jsx'
import WidgetAtencion from '../../components/WidgetAtencion.jsx'
import animacionAuditoria from '../../assets/auditoria.json'

export default function SolicitudAuditoria() {
  const [params] = useSearchParams()
  const navigate = useNavigate()

  useEffect(() => {
    const producto = params.get('producto') || ''
    localStorage.setItem(
      'mercalogro_solicitud_pendiente',
      JSON.stringify({ producto, creadaEn: Date.now() })
    )
  }, [params])

  function regresar() {
    navigate('/')
  }

  return (
    <Layout>
      <div className="max-w-xl mx-auto px-4 py-12">
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3 }}
          className="bg-white rounded-2xl border border-gray-100 p-8 text-center"
        >
          <div className="w-40 h-40 mx-auto">
            <Lottie animationData={animacionAuditoria} loop autoplay />
          </div>

          <h1 className="text-xl font-extrabold text-textoOscuro mt-4">
            Estamos revisando tu información
          </h1>
          <p className="text-sm text-gray-600 mt-2 leading-relaxed">
            Este proceso puede tardar hasta 24 horas. Regresa más tarde.
          </p>

          <div className="mt-6 bg-fondoClaro rounded-xl p-4 text-xs text-gray-600 text-left space-y-1">
            <p>Tu solicitud quedó registrada.</p>
            <p>Puedes seguir viendo productos mientras la revisamos.</p>
            <p>Te avisaremos en cuanto tengamos una respuesta.</p>
          </div>

          <motion.button
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={regresar}
            className="mt-6 w-full bg-principal text-white font-bold py-3 rounded-xl hover:bg-emerald-800 transition-colors"
          >
            Regresar al catálogo
          </motion.button>
        </motion.div>
      </div>

      <WidgetAtencion />
    </Layout>
  )
}