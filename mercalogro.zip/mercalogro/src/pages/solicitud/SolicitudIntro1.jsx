import { useSearchParams, useNavigate, Link } from 'react-router-dom'
import { motion } from 'framer-motion'
import Layout from '../../components/Layout.jsx'
import WidgetAtencion from '../../components/WidgetAtencion.jsx'
import { productosPiloto } from '../../data/productos.js'

export default function SolicitudIntro1() {
  const [params] = useSearchParams()
  const navigate = useNavigate()
  const producto = productosPiloto.find((p) => p.id === params.get('producto'))

  function continuar() {
    navigate(`/solicitud/intro-2?producto=${params.get('producto') || ''}`)
  }

  return (
    <Layout>
      <div className="max-w-3xl mx-auto px-4 py-10">
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3 }}
          className="bg-white rounded-2xl border border-gray-100 overflow-hidden"
        >
          <div className="grid md:grid-cols-2">
            <div className="bg-emerald-50 flex items-center justify-center p-6">
              <img
                src="/hombre.webp"
                alt="Persona interesada en comprar a plazos"
                className="max-h-72 object-contain"
              />
            </div>

            <div className="p-6 md:p-8 flex flex-col justify-center">
              <h1 className="text-2xl font-extrabold text-textoOscuro tracking-tight">
                ¿Cómo funciona?
              </h1>
              <p className="mt-3 text-sm text-gray-600 leading-relaxed">
                Puedes adquirir tu compra a 6 pagos mensuales.
              </p>
              <p className="mt-2 text-sm text-gray-600 leading-relaxed">
                Para continuar, necesitamos revisar tu perfil y verificar tu identidad. La información que nos compartas debe ser real y verificable.
              </p>

              {producto && (
                <p className="mt-4 text-xs text-gray-500">
                  Producto seleccionado: <strong className="text-textoOscuro">{producto.nombre}</strong>
                </p>
              )}

              <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={continuar}
                className="mt-6 w-full bg-principal text-white font-bold py-3 rounded-xl hover:bg-emerald-800 transition-colors"
              >
                Continuar
              </motion.button>

              <Link to="/" className="mt-3 text-center text-xs text-gray-500 hover:text-gray-800">
                Volver a la tienda
              </Link>
            </div>
          </div>
        </motion.div>
      </div>

      <WidgetAtencion />
    </Layout>
  )
}