import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { motion } from 'framer-motion'
import Layout from '../../components/Layout.jsx'
import WidgetAtencion from '../../components/WidgetAtencion.jsx'
import { productosPiloto } from '../../data/productos.js'
import { supabase } from '../../lib/supabase.js'

export default function SolicitudEstado() {
  const [estado, setEstado] = useState('cargando')
  const [solicitud, setSolicitud] = useState(null)

  useEffect(() => {
    let activo = true
    let intervalo

    async function consultar() {
      const pendiente = (() => {
        try {
          return JSON.parse(localStorage.getItem('mercalogro_solicitud_pendiente') || 'null')
        } catch {
          return null
        }
      })()

      if (!pendiente?.producto) {
        if (activo) setEstado('sin-solicitud')
        return
      }

      const { data } = await supabase
        .from('solicitudes')
        .select('*')
        .eq('producto_id', pendiente.producto)
        .order('creado_en', { ascending: false })
        .limit(1)
        .maybeSingle()

      if (!activo) return

      if (data) {
        setSolicitud(data)
        if (data.estado === 'aprobada') {
          localStorage.removeItem('mercalogro_solicitud_pendiente')
          setEstado('aprobada')
        } else if (data.estado === 'rechazada') {
          localStorage.removeItem('mercalogro_solicitud_pendiente')
          setEstado('rechazada')
        } else {
          setEstado('pendiente')
        }
      } else {
        setEstado('pendiente')
      }
    }

    consultar()
    intervalo = setInterval(consultar, 30000)

    return () => {
      activo = false
      clearInterval(intervalo)
    }
  }, [])

  const producto = productosPiloto.find((p) => p.id === solicitud?.producto_id)

  if (estado === 'cargando') {
    return (
      <Layout>
        <div className="max-w-xl mx-auto px-4 py-20 text-center">
          <div className="w-8 h-8 mx-auto border-4 border-principal border-t-transparent rounded-full animate-spin" />
        </div>
      </Layout>
    )
  }

  if (estado === 'sin-solicitud') {
    return (
      <Layout>
        <div className="max-w-xl mx-auto px-4 py-20 text-center">
          <p className="text-gray-500">No tienes una solicitud en curso.</p>
          <Link to="/" className="mt-4 inline-block text-principal font-semibold hover:underline">
            Volver a la tienda
          </Link>
        </div>
      </Layout>
    )
  }

  return (
    <Layout>
      <div className="max-w-xl mx-auto px-4 py-12">
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3 }}
          className="bg-white rounded-2xl border border-gray-100 p-8"
        >
          {estado === 'pendiente' && (
            <>
              <div className="w-12 h-12 mx-auto rounded-full bg-amber-100 flex items-center justify-center">
                <div className="w-6 h-6 border-2 border-amber-500 border-t-transparent rounded-full animate-spin" />
              </div>
              <h1 className="text-xl font-extrabold text-textoOscuro text-center mt-4">
                Solicitud en revisión
              </h1>
              <p className="text-sm text-gray-600 text-center mt-2">
                Estamos revisando tu información. Este proceso puede tardar hasta 24 horas.
              </p>
              {producto && (
                <p className="text-xs text-gray-500 text-center mt-3">
                  Producto: <strong className="text-textoOscuro">{producto.nombre}</strong>
                </p>
              )}
            </>
          )}

          {estado === 'aprobada' && (
            <>
              <div className="w-12 h-12 mx-auto rounded-full bg-emerald-100 flex items-center justify-center">
                <svg className="w-6 h-6 text-principal" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
                  <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
                </svg>
              </div>
              <h1 className="text-xl font-extrabold text-textoOscuro text-center mt-4">
                Solicitud aprobada
              </h1>
              <p className="text-sm text-gray-600 text-center mt-2">
                Ya puedes continuar con tu compra.
              </p>
              {producto && (
                <Link to={`/producto/${producto.id}`} className="block mt-6">
                  <motion.span
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    className="block w-full text-center bg-principal text-white font-bold py-3 rounded-xl hover:bg-emerald-800 transition-colors"
                  >
                    Continuar compra
                  </motion.span>
                </Link>
              )}
            </>
          )}

          {estado === 'rechazada' && (
            <>
              <div className="w-12 h-12 mx-auto rounded-full bg-red-100 flex items-center justify-center">
                <svg className="w-6 h-6 text-red-600" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
                  <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
                </svg>
              </div>
              <h1 className="text-xl font-extrabold text-textoOscuro text-center mt-4">
                Solicitud no aprobada
              </h1>
              <p className="text-sm text-gray-600 text-center mt-2">
                Puedes intentarlo de nuevo más adelante, pero no se garantiza la aprobación ni la disponibilidad del producto.
              </p>
              <Link to="/" className="block mt-6">
                <motion.span
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  className="block w-full text-center bg-fondoClaro text-textoOscuro font-bold py-3 rounded-xl hover:bg-gray-200 transition-colors"
                >
                  Volver a la tienda
                </motion.span>
              </Link>
            </>
          )}
        </motion.div>
      </div>

      <WidgetAtencion />
    </Layout>
  )
}