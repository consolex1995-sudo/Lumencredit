import { useSearchParams, useNavigate } from 'react-router-dom'
import { motion } from 'framer-motion'
import Layout from '../../components/Layout.jsx'
import WidgetAtencion from '../../components/WidgetAtencion.jsx'

export default function SolicitudIntro2() {
  const [params] = useSearchParams()
  const navigate = useNavigate()

  function empezar() {
    navigate(`/solicitud/datos-personales?producto=${params.get('producto') || ''}`)
  }

  function abrirFaq() {
    window.open('/preguntas-frecuentes#pago-inicial', '_blank', 'noopener,noreferrer')
  }

  return (
    <Layout>
      <div className="max-w-2xl mx-auto px-4 py-10">
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3 }}
          className="bg-white rounded-2xl border border-gray-100 p-6 md:p-8"
        >
          <h1 className="text-2xl font-extrabold text-textoOscuro tracking-tight">
            Antes de comenzar
          </h1>

          <p className="mt-4 text-sm text-gray-600 leading-relaxed">
            Recuerda que cualquier compra a plazos requiere obligatoriamente un pago inicial del 10%, sin excepciones y sin importar tu perfil.
          </p>

          <p className="mt-3 text-sm text-gray-600 leading-relaxed">
            Si tienes dudas,{' '}
            <button
              onClick={abrirFaq}
              className="text-principal font-semibold underline underline-offset-2 hover:text-emerald-800"
            >
              consulta aquí cómo funciona
            </button>
            .
          </p>

          <div className="mt-5 bg-fondoClaro rounded-xl p-4">
            <p className="text-sm text-gray-600 leading-relaxed">
              Aunque tu solicitud sea aprobada, cada compra posterior será revisada nuevamente para confirmar el límite disponible.
            </p>
          </div>

          <motion.button
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={empezar}
            className="mt-6 w-full bg-principal text-white font-bold py-3 rounded-xl hover:bg-emerald-800 transition-colors"
          >
            Empezar solicitud
          </motion.button>

          <button
            onClick={() => navigate(-1)}
            className="mt-3 w-full text-xs text-gray-500 hover:text-gray-800"
          >
            Regresar
          </button>
        </motion.div>
      </div>

      <WidgetAtencion />
    </Layout>
  )
}