import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { motion } from 'framer-motion'
import { crearSesionAdmin } from '../components/RutaAdmin.jsx'

export default function AdminLogin() {
  const navigate = useNavigate()
  const [usuario, setUsuario] = useState('')
  const [password, setPassword] = useState('')
  const [token, setToken] = useState('')
  const [error, setError] = useState('')
  const [enviando, setEnviando] = useState(false)

  async function entrar(e) {
    e.preventDefault()
    setError('')

    if (!usuario.trim() || !password || !token.trim()) {
      setError('Completa los tres campos.')
      return
    }

    setEnviando(true)
    try {
      const res = await fetch('/.netlify/functions/admin-auth', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ usuario, password, token })
      })
      const data = await res.json()

      if (!res.ok || !data.ok) {
        setError('Credenciales incorrectas.')
        setEnviando(false)
        return
      }

      crearSesionAdmin()
      navigate('/admin', { replace: true })
    } catch {
      setError('No pudimos validar el acceso. Intenta de nuevo.')
      setEnviando(false)
    }
  }

  return (
    <div className="min-h-screen bg-fondoClaro flex items-center justify-center px-4">
      <motion.form
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3 }}
        onSubmit={entrar}
        className="bg-white rounded-2xl border border-gray-100 shadow-lg p-8 w-full max-w-sm space-y-4"
      >
        <h1 className="text-xl font-extrabold text-textoOscuro text-center">
          Acceso interno
        </h1>

        <input
          type="text"
          value={usuario}
          onChange={(e) => setUsuario(e.target.value)}
          placeholder="Usuario"
          autoComplete="username"
          className="w-full border border-gray-200 rounded-xl px-3 py-2.5 text-sm outline-none focus:border-principal"
        />
        <input
          type="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          placeholder="Contraseña"
          autoComplete="current-password"
          className="w-full border border-gray-200 rounded-xl px-3 py-2.5 text-sm outline-none focus:border-principal"
        />
        <input
          type="password"
          value={token}
          onChange={(e) => setToken(e.target.value)}
          placeholder="Token de seguridad"
          autoComplete="off"
          className="w-full border border-gray-200 rounded-xl px-3 py-2.5 text-sm outline-none focus:border-principal"
        />

        {error && <p className="text-xs text-red-600">{error}</p>}

        <motion.button
          whileHover={{ scale: 1.01 }}
          whileTap={{ scale: 0.99 }}
          type="submit"
          disabled={enviando}
          className="w-full bg-principal text-white font-bold py-3 rounded-xl hover:bg-emerald-800 transition-colors disabled:opacity-60"
        >
          {enviando ? 'Validando…' : 'Entrar'}
        </motion.button>
      </motion.form>
    </div>
  )
}