import { useEffect, useState } from 'react'
import { useLocation } from 'react-router-dom'
import { motion } from 'framer-motion'
import Layout from '../components/Layout.jsx'
import WidgetAtencion from '../components/WidgetAtencion.jsx'

const PESTANAS = [
  { id: 'terminos', nombre: 'Términos y condiciones' },
  { id: 'privacidad', nombre: 'Aviso de privacidad' }
]

export default function Legales() {
  const location = useLocation()
  const [activa, setActiva] = useState('terminos')

  useEffect(() => {
    if (location.hash) {
      const id = location.hash.replace('#', '')
      if (PESTANAS.some((p) => p.id === id)) setActiva(id)
    }
  }, [location.hash])

  return (
    <Layout>
      <div className="max-w-3xl mx-auto px-4 py-10">
        <h1 className="text-2xl font-extrabold text-textoOscuro tracking-tight">
          Documentos legales
        </h1>
        <div className="mt-5 flex gap-2 border-b border-gray-200">
          {PESTANAS.map((p) => (
            <button
              key={p.id}
              onClick={() => setActiva(p.id)}
              className={`px-4 py-2 text-sm font-semibold transition-colors border-b-2 -mb-px ${
                activa === p.id
                  ? 'border-principal text-principal'
                  : 'border-transparent text-gray-500 hover:text-textoOscuro'
              }`}
            >
              {p.nombre}
            </button>
          ))}
        </div>
        <motion.div
          key={activa}
          initial={{ opacity: 0, y: 6 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.25 }}
          className="mt-6 bg-white rounded-2xl border border-gray-100 p-6 md:p-8 text-sm text-gray-600 leading-relaxed"
        >
          {activa === 'terminos' ? <Terminos /> : <Privacidad />}
        </motion.div>
      </div>
      <WidgetAtencion />
    </Layout>
  )
}

function Terminos() {
  return (
    <div className="space-y-4">
      <p className="text-xs text-gray-400">Última actualización: 18 de noviembre de 2026</p>

      <div className="bg-fondoClaro rounded-xl p-4 border border-gray-100">
        <h2 className="font-bold text-textoOscuro text-base mb-2">IDENTIDAD Y DOMICILIO FISCAL</h2>
        <p className="text-xs leading-relaxed">
          Mercalogro Servicios Comerciales y de Distribución S.A. de C.V. (en lo sucesivo "La Empresa"), con domicilio fiscal ubicado en Lic. Manuel Gómez Morín #3870, Piso 5, Oficina 502, Centro Sur, C.P. 76090, Santiago de Querétaro, Querétaro, es la responsable del tratamiento, comercialización y administración de la plataforma digital, así como de la gestión de pedidos, planes de apartado y financiamiento comercial de productos de entretenimiento, consolas y accesorios.
        </p>
        <p className="text-xs leading-relaxed mt-2">
          <strong>Nota logística y de operaciones:</strong> Las oficinas antes citadas fungen exclusivamente como domicilio fiscal y administrativo de gestión corporativa. Las operaciones de recepción de pagos iniciales autorizados, entrega física y esquema Click & Collect se realizan de manera independiente en nuestro módulo de recolección ubicado en Interior Plaza Galerías Constituyentes, Av. Constituyentes Ote. #34, Local Comercial B-12 (Zona de Servicios / Recepción Logística), Colonia Mercurio, C.P. 76040, Santiago de Querétaro, Querétaro, previa cita y validación de folios de crédito.
        </p>
      </div>

      <h2 className="font-bold text-textoOscuro">1. Aceptación</h2>
      <p>Al utilizar los servicios de Mercalogro y solicitar una compra a plazos, aceptas los presentes Términos y Condiciones. Si no estás de acuerdo, no debes utilizar el servicio.</p>

      <h2 className="font-bold text-textoOscuro">2. Descripción del servicio</h2>
      <p>Mercalogro ofrece la venta de consolas, videojuegos, accesorios y productos relacionados, con la opción de compra a plazos en 6 mensualidades. El servicio consiste en la evaluación de tu perfil, la verificación de tu identidad y, en su caso, la autorización de la compra a plazos. Mercalogro es una empresa comercial/retail con esquema de ventas a plazos internos; no es institución financiera ni requiere registro ante SIPRES o CONDUSEF.</p>

      <h2 className="font-bold text-textoOscuro">3. Requisitos para la compra a plazos</h2>
      <p>Para solicitar una compra a plazos, debes ser mayor de edad, proporcionar información real y verificable, contar con identificación oficial vigente (INE) y aceptar la verificación de identidad mediante biometría.</p>

      <h2 className="font-bold text-textoOscuro">4. Pago inicial</h2>
      <p>Toda compra a plazos requiere un pago inicial obligatorio del 10% del precio total del producto. Este pago inicial es requisito indispensable y no es reembolsable una vez realizada la verificación y aprobada la compra, salvo error atribuible a Mercalogro.</p>

      <h2 className="font-bold text-textoOscuro">5. Plazos y pagos</h2>
      <p>El saldo restante se cubrirá en 6 mensualidades. El precio total a plazos incluye los intereses correspondientes, los cuales se informan al momento de la compra. El Costo Anual Total (CAT) se muestra en el resumen de compra y en el contrato.</p>

      <h2 className="font-bold text-textoOscuro">6. Métodos de pago</h2>
      <p>El pago inicial y las mensualidades podrán realizarse en tiendas físicas autorizadas (Walmart, Bodega Aurrerá, 7-Eleven, Farmacias del Ahorro, Soriana), mediante número de referencia asignado por Mercalogro, o en efectivo/tarjeta en nuestro módulo de recolección en Plaza Galerías Constituyentes, con entrega del producto en el mismo lugar. No se aceptan transferencias bancarias directas ni pagos por pasarelas en línea.</p>

      <h2 className="font-bold text-textoOscuro">7. Envío y recolección</h2>
      <p>El envío es gratuito cuando el pago se realiza en tiendas físicas. Si el cliente elige pagar y recoger en nuestro módulo de Plaza Galerías Constituyentes, no aplica envío. La fecha de disponibilidad o entrega será asignada por Mercalogro al aprobar la compra y se comunicará al cliente en su pantalla de pago.</p>

      <h2 className="font-bold text-textoOscuro">8. Verificación de identidad</h2>
      <p>Mercalogro realiza la verificación de identidad mediante la captura del frente de la INE y una selfie. La información se utiliza únicamente para validar tu identidad y evaluar tu perfil.</p>

      <h2 className="font-bold text-textoOscuro">9. Evaluación del perfil</h2>
      <p>La aprobación de la compra a plazos está sujeta a la evaluación del perfil crediticio del cliente. Mercalogro se reserva el derecho de aprobar o rechazar solicitudes sin necesidad de expresar motivos.</p>

      <h2 className="font-bold text-textoOscuro">10. Comprobantes de pago</h2>
      <p>El cliente puede subir una fotografía de su comprobante de pago como respaldo. Este comprobante no sustituye la confirmación del sistema, que procesará el pago automáticamente.</p>

      <h2 className="font-bold text-textoOscuro">11. Cancelación y expiración</h2>
      <p>Si el cliente no realiza el pago inicial dentro del plazo establecido, la compra se cancelará y el producto se liberará a existencias. No se garantiza la disponibilidad del producto en un segundo intento.</p>

      <h2 className="font-bold text-textoOscuro">12. Garantía</h2>
      <p>Todos los productos cuentan con una garantía de 1 año sin costo adicional. Si el producto presenta alguna falla o defecto de fábrica, el cliente puede solicitar la devolución sin costo alguno, incluyendo el envío de regreso.</p>

      <h2 className="font-bold text-textoOscuro">13. Devoluciones</h2>
      <p><strong>13.1. Producto sin abrir:</strong> el cliente puede devolver el producto dentro de los 7 días posteriores a su recepción, siempre que conserve su empaque original y no haya sido abierto. No se aplica penalización, pero el costo de envío de la devolución corre a cargo del cliente y se descuenta del reembolso.</p>
      <p><strong>13.2. Producto abierto:</strong> si el producto ya fue abierto, el cliente puede devolverlo dentro de los 7 días posteriores a su recepción, con una penalización del 17% sobre el precio del producto, que incluye el costo de envío y comisión. Si el cliente ya pagó el 10% inicial, solo deberá cubrir el 7% restante.</p>
      <p><strong>13.3. Falla de fábrica:</strong> si el producto presenta una falla o defecto de fábrica, el cliente puede devolverlo sin costo alguno, sin penalización y sin costo de envío de regreso, cubierto por la garantía de 1 año.</p>

      <h2 className="font-bold text-textoOscuro">14. Propiedad del producto</h2>
      <p>El producto se entrega al cliente una vez confirmado el pago inicial y, en su caso, el envío. La propiedad se transfiere al cliente al momento de la entrega.</p>

      <h2 className="font-bold text-textoOscuro">15. Datos personales</h2>
      <p>El tratamiento de tus datos personales se rige por el Aviso de Privacidad de Mercalogro.</p>

      <h2 className="font-bold text-textoOscuro">16. Modificaciones</h2>
      <p>Mercalogro se reserva el derecho de modificar estos Términos y Condiciones. Las modificaciones serán publicadas en esta página.</p>

      <h2 className="font-bold text-textoOscuro">17. Legislación aplicable</h2>
      <p>Estos Términos y Condiciones se rigen por las leyes de los Estados Unidos Mexicanos.</p>
    </div>
  )
}

function Privacidad() {
  return (
    <div className="space-y-4">
      <p className="text-xs text-gray-400">Última actualización: 18 de noviembre de 2026</p>

      <h2 className="font-bold text-textoOscuro">1. Responsable</h2>
      <p>Mercalogro Servicios Comerciales y de Distribución S.A. de C.V., con domicilio fiscal en Lic. Manuel Gómez Morín #3870, Piso 5, Oficina 502 (Torre Lomas), Colonia Centro Sur, C.P. 76090, Santiago de Querétaro, Querétaro, es responsable del tratamiento de tus datos personales.</p>

      <h2 className="font-bold text-textoOscuro">2. Datos que recabamos</h2>
      <p>Para llevar a cabo la compra a plazos, recabamos los siguientes datos personales: nombre completo (nombre, apellido paterno, apellido materno); CURP y RFC; fecha de nacimiento; teléfono y correo electrónico; domicilio de envío (cuando aplique); datos laborales (ocupación, ingresos mensuales, antigüedad); fotografía del frente de tu INE y selfie (verificación de identidad); historial de compras y pagos.</p>

      <h2 className="font-bold text-textoOscuro">3. Finalidades del tratamiento</h2>
      <p>Tus datos serán utilizados para verificar tu identidad, evaluar tu perfil crediticio, procesar tu solicitud de compra a plazos, gestionar pagos, envíos y comprobantes, y cumplir con obligaciones legales y regulatorias.</p>

      <h2 className="font-bold text-textoOscuro">4. Compartición de datos</h2>
      <p>Mercalogro podrá compartir tus datos personales con Buró de Crédito, para la evaluación de tu perfil crediticio; con paqueterías, para la entrega de los productos; y con proveedores de servicios de pago, para el procesamiento de pagos en tiendas o en nuestro módulo de recolección.</p>

      <h2 className="font-bold text-textoOscuro">5. Derechos ARCO</h2>
      <p>Puedes ejercer tus derechos de Acceso, Rectificación, Cancelación y Oposición (ARCO) contactando a Mercalogro a través de los medios disponibles en la página. No contamos con correo electrónico de contacto para temas de privacidad.</p>

      <h2 className="font-bold text-textoOscuro">6. Cambios al aviso</h2>
      <p>Mercalogro se reserva el derecho de modificar este Aviso de Privacidad. Las modificaciones serán publicadas en esta página.</p>

      <h2 className="font-bold text-textoOscuro">7. Consentimiento</h2>
      <p>Al proporcionar tus datos personales y continuar con el proceso de compra a plazos, aceptas los términos de este Aviso de Privacidad.</p>
    </div>
  )
}