import { useEffect, useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { motion } from 'framer-motion'
import Layout from '../components/Layout.jsx'
import WidgetAtencion from '../components/WidgetAtencion.jsx'
import { supabase } from '../lib/supabase.js'

const CLAVE_DIRECCION = 'mercalogro_direccion_mi_cuenta'

function formatoMoneda(n) {
  return Number(n || 0).toLocaleString('es-MX', { style: 'currency', currency: 'MXN', maximumFractionDigits: 0 })
}

function formatoFecha(f) {
  if (!f) return '—'
  const d = new Date(f)
  return d.toLocaleDateString('es-MX', { day: '2-digit', month: 'short', year: 'numeric' })
}

export default function MiCuenta() {
  const navigate = useNavigate()
  const [cargando, setCargando] = useState(true)
  const [perfil, setPerfil] = useState(null)
  const [compras, setCompras] = useState([])
  const [pagos, setPagos] = useState([])
  const [direccion, setDireccion] = useState(null)
  const [editandoDireccion, setEditandoDireccion] = useState(false)
  const [formDir, setFormDir] = useState({
    nombreRecibe: '', telefono: '', cp: '', calle: '', numero: '',
    colonia: '', ciudad: '', estado: '', referencias: ''
  })
  const [error, setError] = useState('')

  useEffect(() => {
    let activo = true

    async function cargar() {
      const { data: sessionData } = await supabase.auth.getSession()
      if (!sessionData?.session) {
        navigate('/')
        return
      }
      const userId = sessionData.session.user.id

      const { data: perfilData } = await supabase
        .from('perfiles')
        .select('*')
        .eq('id', userId)
        .maybeSingle()

      const { data: comprasData } = await supabase
        .from('compras')
        .select('*')
        .eq('usuario_id', userId)
        .order('creado_en', { ascending: false })

      const { data: pagosData } = await supabase
        .from('pagos')
        .select('*')
        .eq('usuario_id', userId)
        .order('fecha_vencimiento', { ascending: true })

      let dir = null
      try {
        const raw = localStorage.getItem(CLAVE_DIRECCION)
        if (raw) dir = JSON.parse(raw)
      } catch {}

      if (!activo) return
      setPerfil(perfilData)
      setCompras(comprasData || [])
      setPagos(pagosData || [])
      setDireccion(dir)
      if (dir) setFormDir((f) => ({ ...f, ...dir }))
      setCargando(false)
    }

    cargar()
    return () => {
      activo = false
    }
  }, [navigate])

  function cambiarDir(campo, valor) {
    setFormDir((f) => ({ ...f, [campo]: valor }))
  }

  function guardarDireccion() {
    const obligatorios = ['nombreRecibe', 'telefono', 'cp', 'calle', 'numero', 'colonia', 'ciudad', 'estado']
    for (const c of obligatorios) {
      if (!formDir[c]?.trim()) {
        setError('Completa todos los campos de la dirección.')
        return
      }
    }
    if (formDir.telefono.replace(/\D/g, '').length !== 10) {
      setError('El teléfono debe tener 10 dígitos.')
      return
    }
    setError('')
    localStorage.setItem(CLAVE_DIRECCION, JSON.stringify(formDir))
    setDireccion(formDir)
    setEditandoDireccion(false)
  }

  if (cargando) {
    return (
      <Layout>
        <div className="max-w-4xl mx-auto px-4 py-20 text-center">
          <div className="w-8 h-8 mx-auto border-4 border-principal border-t-transparent rounded-full animate-spin" />
        </div>
      </Layout>
    )
  }

  return (
    <Layout>
      <div className="max-w-4xl mx-auto px-4 py-8 space-y-6">
        <div>
          <h1 className="text-2xl font-extrabold text-textoOscuro tracking-tight">Mi cuenta</h1>
          <p className="text-sm text-gray-500 mt-1">
            {perfil?.nombre ? `${perfil.nombre} ${perfil.apellido_paterno || ''}` : 'Bienvenido'}
          </p>
        </div>

        <motion.section
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-2xl border border-gray-100 p-5"
        >
          <div className="flex items-center justify-between">
            <h2 className="font-bold text-textoOscuro">Dirección</h2>
            {direccion && !editandoDireccion && (
              <button
                onClick={() => setEditandoDireccion(true)}
                className="text-xs font-semibold text-principal hover:underline flex items-center gap-1"
              >
                <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                  <path strokeLinecap="round" strokeLinejoin="round" d="M15.232 5.232l3.536 3.536M9 13l6.586-6.586a2 2 0 112.828 2.828L11.828 15.828 7 17l1.172-4.828z" />
                </svg>
                Editar
              </button>
            )}
          </div>

          {!direccion && !editandoDireccion && (
            <button
              onClick={() => setEditandoDireccion(true)}
              className="mt-2 text-sm font-semibold text-principal hover:underline"
            >
              Agregar dirección
            </button>
          )}

          {direccion && !editandoDireccion && (
            <div className="mt-2 text-sm text-gray-600">
              <p>{direccion.nombreRecibe} — {direccion.telefono}</p>
              <p>{direccion.calle} {direccion.numero}, {direccion.colonia}</p>
              <p>{direccion.ciudad}, {direccion.estado}, CP {direccion.cp}</p>
            </div>
          )}

          {editandoDireccion && (
            <div className="mt-3 space-y-3">
              <div className="grid sm:grid-cols-2 gap-3">
                <Campo label="Nombre de quien recibe" valor={formDir.nombreRecibe} cambiar={(v) => cambiarDir('nombreRecibe', v)} />
                <Campo label="Teléfono" valor={formDir.telefono} cambiar={(v) => cambiarDir('telefono', v.replace(/\D/g, '').slice(0, 10))} inputMode="numeric" />
                <Campo label="Código postal" valor={formDir.cp} cambiar={(v) => cambiarDir('cp', v.replace(/\D/g, '').slice(0, 5))} inputMode="numeric" />
                <Campo label="Estado" valor={formDir.estado} cambiar={(v) => cambiarDir('estado', v)} />
                <Campo label="Calle" valor={formDir.calle} cambiar={(v) => cambiarDir('calle', v)} />
                <Campo label="Número" valor={formDir.numero} cambiar={(v) => cambiarDir('numero', v)} />
                <Campo label="Colonia" valor={formDir.colonia} cambiar={(v) => cambiarDir('colonia', v)} />
                <Campo label="Ciudad" valor={formDir.ciudad} cambiar={(v) => cambiarDir('ciudad', v)} />
              </div>
              <div>
                <label className="block text-xs font-semibold text-gray-600 mb-1">Referencias (opcional)</label>
                <textarea
                  value={formDir.referencias}
                  onChange={(e) => cambiarDir('referencias', e.target.value)}
                  rows={2}
                  className="w-full border border-gray-200 rounded-xl px-3 py-2 text-sm outline-none focus:border-principal resize-none"
                />
              </div>
              {error && <p className="text-xs text-red-600">{error}</p>}
              <div className="flex gap-2">
                <button
                  onClick={guardarDireccion}
                  className="flex-1 bg-principal text-white font-bold py-2.5 rounded-xl hover:bg-emerald-800 transition-colors"
                >
                  Guardar
                </button>
                <button
                  onClick={() => { setEditandoDireccion(false); setError('') }}
                  className="flex-1 bg-fondoClaro text-textoOscuro font-bold py-2.5 rounded-xl hover:bg-gray-200 transition-colors"
                >
                  Cancelar
                </button>
              </div>
            </div>
          )}
        </motion.section>

        <motion.section
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.05 }}
          className="bg-white rounded-2xl border border-gray-100 p-5"
        >
          <h2 className="font-bold text-textoOscuro">Mis compras</h2>

          {compras.length === 0 ? (
            <p className="mt-3 text-sm text-gray-500">Historial vacío.</p>
          ) : (
            <div className="mt-3 divide-y divide-gray-100">
              {compras.map((c) => (
                <div key={c.id} className="py-3 flex items-center justify-between gap-3">
                  <div>
                    <p className="text-sm font-semibold text-textoOscuro">{c.producto_nombre}</p>
                    <p className="text-xs text-gray-500">
                      {c.tipo === 'contado' ? 'Contado' : 'A plazos'} — {formatoMoneda(c.precio_total)}
                    </p>
                    <p className="text-[11px] text-gray-400">Estado: {c.estado}</p>
                  </div>
                  {c.estado === 'pendiente_pago' && (
                    <Link
                      to={`/pago-inicial?compra=${c.id}`}
                      className="text-xs font-semibold text-principal hover:underline shrink-0"
                    >
                      Pagar inicial
                    </Link>
                  )}
                </div>
              ))}
            </div>
          )}
        </motion.section>

        <motion.section
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="bg-white rounded-2xl border border-gray-100 p-5"
        >
          <h2 className="font-bold text-textoOscuro">Historial de pagos</h2>

          {pagos.length === 0 ? (
            <p className="mt-3 text-sm text-gray-500">Aún no tienes pagos registrados.</p>
          ) : (
            <div className="mt-3 divide-y divide-gray-100">
              {pagos.map((p) => (
                <div key={p.id} className="py-3 flex items-center justify-between gap-3">
                  <div>
                    <p className="text-sm font-semibold text-textoOscuro">{formatoMoneda(p.monto)}</p>
                    <p className="text-xs text-gray-500">Vence: {formatoFecha(p.fecha_vencimiento)}</p>
                  </div>
                  <span className={`text-[11px] font-bold px-2 py-1 rounded-full ${
                    p.estado === 'pagado' ? 'bg-emerald-100 text-principal' : 'bg-amber-100 text-amber-700'
                  }`}>
                    {p.estado === 'pagado' ? 'Pagado' : 'Pendiente'}
                  </span>
                </div>
              ))}
            </div>
          )}
        </motion.section>
      </div>

      <WidgetAtencion />
    </Layout>
  )
}

function Campo({ label, valor, cambiar, inputMode }) {
  return (
    <div>
      <label className="block text-xs font-semibold text-gray-600 mb-1">{label}</label>
      <input
        type="text"
        value={valor}
        inputMode={inputMode}
        onChange={(e) => cambiar(e.target.value)}
        className="w-full border border-gray-200 rounded-xl px-3 py-2 text-sm outline-none focus:border-principal"
      />
    </div>
  )
}