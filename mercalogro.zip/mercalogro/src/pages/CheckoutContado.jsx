import { useState } from 'react'
import { useSearchParams, useNavigate, Link } from 'react-router-dom'
import { motion } from 'framer-motion'
import Layout from '../components/Layout.jsx'
import WidgetAtencion from '../components/WidgetAtencion.jsx'
import { productosPiloto } from '../data/productos.js'
import { supabase } from '../lib/supabase.js'

function formatoMoneda(n) {
  return n.toLocaleString('es-MX', { style: 'currency', currency: 'MXN', maximumFractionDigits: 0 })
}

const CLAVE_DIRECCION = 'mercalogro_direccion_contado'

export default function CheckoutContado() {
  const [params] = useSearchParams()
  const navigate = useNavigate()
  const producto = productosPiloto.find((p) => p.id === params.get('producto'))

  const [form, setForm] = useState({
    nombreRecibe: '',
    telefono: '',
    cp: '',
    calle: '',
    numero: '',
    colonia: '',
    ciudad: '',
    estado: '',
    referencias: ''
  })
  const [modalRegistro, setModalRegistro] = useState(false)
  const [correo, setCorreo] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')
  const [paso, setPaso] = useState('formulario')

  if (!producto) {
    return (
      <Layout>
        <div className="max-w-3xl mx-auto px-4 py-20 text-center">
          <p className="text-gray-500">Producto no encontrado.</p>
          <Link to="/" className="mt-4 inline-block text-principal font-semibold hover:underline">
            Volver a la tienda
          </Link>
        </div>
      </Layout>
    )
  }

  const envioGratis = producto.precioContado >= 600

  function cambiar(campo, valor) {
    setForm((f) => ({ ...f, [campo]: valor }))
  }

  function continuar(e) {
    e.preventDefault()
    const obligatorios = ['nombreRecibe', 'telefono', 'cp', 'calle', 'numero', 'colonia', 'ciudad', 'estado']
    for (const campo of obligatorios) {
      if (!form[campo]?.trim()) {
        setError(`El campo "${campo}" es obligatorio.`)
        return
      }
    }
    if (form.telefono.replace(/\D/g, '').length !== 10) {
      setError('El teléfono debe tener 10 dígitos.')
      return
    }
    if (form.cp.replace(/\D/g, '').length !== 5) {
      setError('El código postal debe tener 5 dígitos.')
      return
    }
    setError('')
    localStorage.setItem(CLAVE_DIRECCION, JSON.stringify(form))

    supabase.auth.getSession().then(({ data }) => {
      if (data?.session) {
        setPaso('paqueteria')
      } else {
        setModalRegistro(true)
      }
    })
  }

  async function registrarse(e) {
    e.preventDefault()
    if (password.length < 10) {
      setError('La contraseña debe tener al menos 10 caracteres.')
      return
    }
    if (!/[a-zA-Z]/.test(password) || !/\d/.test(password)) {
      setError('La contraseña debe incluir al menos una letra y un número.')
      return
    }

    const { error: err } = await supabase.auth.signUp({ email: correo, password })
    if (err) {
      if (err.message.toLowerCase().includes('already registered')) {
        setError('Ya tienes cuenta. Inicia sesión con tu contraseña.')
        setPaso('login-rapido')
        return
      }
      setError(err.message)
      return
    }
    setError('')
    setModalRegistro(false)
    setPaso('paqueteria')
  }

  async function loginRapido(e) {
    e.preventDefault()
    const { error: err } = await supabase.auth.signInWithPassword({ email: correo, password })
    if (err) {
      setError('Contraseña incorrecta. Intenta de nuevo.')
      return
    }
    setError('')
    setModalRegistro(false)
    setPaso('paqueteria')
  }

  return (
    <Layout>
      <div className="max-w-3xl mx-auto px-4 py-8">
        <h1 className="text-2xl font-extrabold text-textoOscuro tracking-tight">Finaliza tu compra</h1>
        <p className="text-sm text-gray-500 mt-1">{producto.nombre}</p>

        {paso === 'formulario' && (
          <motion.form
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.25 }}
            onSubmit={continuar}
            className="mt-6 bg-white rounded-2xl border border-gray-100 p-5 space-y-4"
          >
            <h2 className="font-bold text-textoOscuro">Dirección de envío</h2>

            <div className="grid sm:grid-cols-2 gap-3">
              <Campo label="Nombre de quien recibe" valor={form.nombreRecibe} cambiar={(v) => cambiar('nombreRecibe', v)} />
              <Campo label="Teléfono de contacto" valor={form.telefono} cambiar={(v) => cambiar('telefono', v.replace(/\D/g, '').slice(0, 10))} inputMode="numeric" />
              <Campo label="Código postal" valor={form.cp} cambiar={(v) => cambiar('cp', v.replace(/\D/g, '').slice(0, 5))} inputMode="numeric" />
              <Campo label="Estado" valor={form.estado} cambiar={(v) => cambiar('estado', v)} />
              <Campo label="Calle" valor={form.calle} cambiar={(v) => cambiar('calle', v)} />
              <Campo label="Número" valor={form.numero} cambiar={(v) => cambiar('numero', v)} />
              <Campo label="Colonia" valor={form.colonia} cambiar={(v) => cambiar('colonia', v)} />
              <Campo label="Ciudad" valor={form.ciudad} cambiar={(v) => cambiar('ciudad', v)} />
            </div>

            <div>
              <label className="block text-xs font-semibold text-gray-600 mb-1">Referencias (opcional)</label>
              <textarea
                value={form.referencias}
                onChange={(e) => cambiar('referencias', e.target.value)}
                rows={2}
                className="w-full border border-gray-200 rounded-xl px-3 py-2 text-sm outline-none focus:border-principal resize-none"
              />
            </div>

            <p className="text-xs text-gray-500">
              Esta información se guardará en tu cuenta para que puedas rastrear el envío. Accede con tu correo.
            </p>

            {envioGratis && (
              <p className="text-xs font-semibold text-principal">Envío gratis en esta compra.</p>
            )}

            {error && <p className="text-xs text-red-600">{error}</p>}

            <motion.button
              whileHover={{ scale: 1.01 }}
              whileTap={{ scale: 0.99 }}
              type="submit"
              className="w-full bg-principal text-white font-bold py-3 rounded-xl hover:bg-emerald-800 transition-colors"
            >
              Continuar
            </motion.button>
          </motion.form>
        )}

        {paso === 'paqueteria' && (
          <motion.div
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            className="mt-6 bg-white rounded-2xl border border-gray-100 p-5 space-y-4"
          >
            <h2 className="font-bold text-textoOscuro">Paquetería</h2>
            <p className="text-sm text-gray-600">Paquetería Mercalogro</p>
            <p className="text-xs text-gray-500">Tiempo máximo de entrega: 3 días hábiles, sujeto a disponibilidad.</p>

            <div className="border-t border-gray-100 pt-4">
              <p className="text-sm font-semibold text-textoOscuro">Pago contraentrega</p>
              <p className="text-xs text-gray-500 mt-1">
                Pagas al momento de recibir tu producto en tu domicilio.
              </p>
            </div>

            {error && <p className="text-xs text-red-600">{error}</p>}

            <div className="flex gap-2">
              <motion.button
                whileHover={{ scale: 1.01 }}
                whileTap={{ scale: 0.99 }}
                onClick={() => navigate(`/checkout-contado/pago?producto=${producto.id}`)}
                className="flex-1 bg-principal text-white font-bold py-3 rounded-xl hover:bg-emerald-800 transition-colors"
              >
                Continuar al pago
              </motion.button>
            </div>
          </motion.div>
        )}
      </div>

      {modalRegistro && (
        <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4">
          <motion.form
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            onSubmit={paso === 'login-rapido' ? loginRapido : registrarse}
            className="bg-white rounded-2xl shadow-2xl w-full max-w-sm p-6 space-y-3"
          >
            <h2 className="text-lg font-extrabold text-textoOscuro">
              {paso === 'login-rapido' ? 'Inicia sesión' : 'Crea tu cuenta'}
            </h2>
            <p className="text-xs text-gray-500">
              Con esta información podrás acceder y revisar el estado de tu compra.
            </p>

            <input
              type="email"
              required
              value={correo}
              onChange={(e) => setCorreo(e.target.value)}
              placeholder="Correo electrónico"
              className="w-full border border-gray-200 rounded-xl px-3 py-2 text-sm outline-none focus:border-principal"
            />
            <input
              type="password"
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Contraseña (mín. 10 caracteres, letra y número)"
              className="w-full border border-gray-200 rounded-xl px-3 py-2 text-sm outline-none focus:border-principal"
            />

            {error && <p className="text-xs text-red-600">{error}</p>}

            <button
              type="submit"
              className="w-full bg-principal text-white font-bold py-2.5 rounded-xl hover:bg-emerald-800 transition-colors"
            >
              {paso === 'login-rapido' ? 'Entrar' : 'Crear cuenta y continuar'}
            </button>
          </motion.form>
        </div>
      )}

      <WidgetAtencion />
    </Layout>
  )
}

function Campo({ label, valor, cambiar, inputMode }) {
  return (
    <div>
      <label className="block text-xs font-semibold text-gray-600 mb-1">{label}</label>
      <input
        type="text"
        value={valor}
        inputMode={inputMode}
        onChange={(e) => cambiar(e.target.value)}
        className="w-full border border-gray-200 rounded-xl px-3 py-2 text-sm outline-none focus:border-principal"
      />
    </div>
  )
}