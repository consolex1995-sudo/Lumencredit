import { useMemo, useState } from 'react'
import { useSearchParams } from 'react-router-dom'
import { motion } from 'framer-motion'
import Layout from '../components/Layout.jsx'
import Buscador from '../components/Buscador.jsx'
import SelectorUbicacion from '../components/SelectorUbicacion.jsx'
import BannerOferta from '../components/BannerOferta.jsx'
import TarjetaProducto from '../components/TarjetaProducto.jsx'
import WidgetAtencion from '../components/WidgetAtencion.jsx'
import BannerSolicitud from '../components/BannerSolicitud.jsx'
import { productosPiloto, categorias } from '../data/productos.js'

export default function Tienda() {
  const [params, setParams] = useSearchParams()
  const categoriaActiva = params.get('categoria') || 'todas'
  const busqueda = (params.get('q') || '').toLowerCase().trim()

  const productosFiltrados = useMemo(() => {
    return productosPiloto.filter((p) => {
      const coincideCategoria = categoriaActiva === 'todas' || p.categoria === categoriaActiva
      const coincideBusqueda =
        !busqueda ||
        p.nombre.toLowerCase().includes(busqueda) ||
        p.descripcion.toLowerCase().includes(busqueda)
      return coincideCategoria && coincideBusqueda
    })
  }, [categoriaActiva, busqueda])

  function cambiarCategoria(id) {
    const nuevos = new URLSearchParams(params)
    if (id === 'todas') nuevos.delete('categoria')
    else nuevos.set('categoria', id)
    setParams(nuevos, { replace: true })
  }

  return (
    <Layout>
      <BannerOferta />

      <section className="bg-white border-b border-gray-100">
        <div className="max-w-6xl mx-auto px-4 py-8 md:py-12">
          <motion.h1
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.25 }}
            className="text-2xl md:text-4xl font-extrabold text-textoOscuro tracking-tight"
          >
            Todo para tu setup, a tu ritmo
          </motion.h1>
          <p className="text-sm md:text-base text-gray-500 mt-2">
            Consolas, juegos, accesorios y sillas. Compra de contado o a 6 pagos mensuales.
          </p>

          <div className="mt-6 space-y-3">
            <Buscador />
            <SelectorUbicacion />
          </div>

          <div className="mt-6 flex gap-2 overflow-x-auto no-scrollbar pb-1">
            <button
              onClick={() => cambiarCategoria('todas')}
              className={`shrink-0 px-4 py-2 rounded-full text-sm font-semibold transition-colors ${
                categoriaActiva === 'todas'
                  ? 'bg-principal text-white'
                  : 'bg-fondoClaro text-textoOscuro hover:bg-emerald-50'
              }`}
            >
              Todas
            </button>
            {categorias.map((c) => (
              <button
                key={c.id}
                onClick={() => cambiarCategoria(c.id)}
                className={`shrink-0 px-4 py-2 rounded-full text-sm font-semibold transition-colors ${
                  categoriaActiva === c.id
                    ? 'bg-principal text-white'
                    : 'bg-fondoClaro text-textoOscuro hover:bg-emerald-50'
                }`}
              >
                {c.nombre}
              </button>
            ))}
          </div>
        </div>
      </section>

      <section className="max-w-6xl mx-auto px-4 py-8">
        {productosFiltrados.length === 0 ? (
          <div className="text-center py-16">
            <p className="text-gray-500">No encontramos productos con esos filtros.</p>
            <button
              onClick={() => setParams({}, { replace: true })}
              className="mt-4 text-principal font-semibold hover:underline"
            >
              Ver todos los productos
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {productosFiltrados.map((p, i) => (
              <TarjetaProducto key={p.id} producto={p} index={i} />
            ))}
          </div>
        )}
      </section>

      <WidgetAtencion />
      <BannerSolicitud />
    </Layout>
  )
}