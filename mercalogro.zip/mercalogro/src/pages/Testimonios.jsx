import { motion } from 'framer-motion'
import Layout from '../components/Layout.jsx'
import WidgetAtencion from '../components/WidgetAtencion.jsx'
import { testimonios } from '../data/testimonios.js'

export default function Testimonios() {
  return (
    <Layout>
      <div className="max-w-4xl mx-auto px-4 py-10">
        <h1 className="text-2xl font-extrabold text-textoOscuro tracking-tight">
          Lo que dicen nuestros clientes
        </h1>
        <p className="text-sm text-gray-500 mt-1">
          Opiniones reales de personas que ya compraron con nosotros.
        </p>

        <div className="mt-6 grid sm:grid-cols-2 gap-4">
          {testimonios.map((t, i) => (
            <motion.div
              key={t.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.25, delay: Math.min(i * 0.05, 0.4) }}
              whileHover={{ y: -3 }}
              className="bg-white rounded-2xl border border-gray-100 p-5 shadow-sm hover:shadow-md transition-shadow"
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-emerald-100 text-principal font-extrabold flex items-center justify-center">
                  {t.nombre.charAt(0).toUpperCase()}
                </div>
                <div>
                  <p className="text-sm font-bold text-textoOscuro">{t.nombre}</p>
                  <p className="text-[11px] text-gray-400">{t.ciudad}</p>
                </div>
              </div>

              <div className="flex gap-0.5 mt-3">
                {[1, 2, 3, 4, 5].map((n) => (
                  <svg
                    key={n}
                    className={`w-4 h-4 ${n <= t.calificacion ? 'text-acento' : 'text-gray-200'}`}
                    fill="currentColor"
                    viewBox="0 0 20 20"
                  >
                    <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.286 3.958a1 1 0 00.95.69h4.162c.969 0 1.371 1.24.588 1.81l-3.367 2.446a1 1 0 00-.363 1.118l1.287 3.957c.3.922-.755 1.688-1.539 1.118l-3.367-2.446a1 1 0 00-1.175 0l-3.367 2.446c-.784.57-1.838-.196-1.539-1.118l1.287-3.957a1 1 0 00-.363-1.118L2.075 9.385c-.783-.57-.38-1.81.588-1.81h4.162a1 1 0 00.95-.69l1.286-3.958z" />
                  </svg>
                ))}
              </div>

              <p className="mt-3 text-sm text-gray-600 leading-relaxed">
                “{t.texto}”
              </p>

              {t.producto && (
                <p className="mt-3 text-[11px] text-gray-400">
                  Compró: {t.producto}
                </p>
              )}
            </motion.div>
          ))}
        </div>
      </div>

      <WidgetAtencion />
    </Layout>
  )
}