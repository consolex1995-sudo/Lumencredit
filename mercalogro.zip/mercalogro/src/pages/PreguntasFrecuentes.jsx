import { useEffect, useState } from 'react'
import { useLocation } from 'react-router-dom'
import { motion, AnimatePresence } from 'framer-motion'
import Layout from '../components/Layout.jsx'
import WidgetAtencion from '../components/WidgetAtencion.jsx'
import { faqs } from '../data/faqs.js'

export default function PreguntasFrecuentes() {
  const location = useLocation()
  const [abierta, setAbierta] = useState(null)

  useEffect(() => {
    if (location.hash) {
      const id = location.hash.replace('#', '')
      setAbierta(id)
      setTimeout(() => {
        const el = document.getElementById(id)
        if (el) el.scrollIntoView({ behavior: 'smooth', block: 'start' })
      }, 100)
    }
  }, [location.hash])

  function alternar(id) {
    setAbierta((a) => (a === id ? null : id))
  }

  return (
    <Layout>
      <div className="max-w-3xl mx-auto px-4 py-10">
        <h1 className="text-2xl font-extrabold text-textoOscuro tracking-tight">
          Preguntas frecuentes
        </h1>
        <p className="text-sm text-gray-500 mt-1">
          Encuentra respuestas a las dudas más comunes sobre tu compra.
        </p>

        <div className="mt-6 space-y-2">
          {faqs.map((f) => (
            <div
              key={f.id}
              id={f.id}
              className="bg-white rounded-2xl border border-gray-100 overflow-hidden"
            >
              <button
                onClick={() => alternar(f.id)}
                className="w-full text-left px-5 py-4 flex items-center justify-between gap-4 hover:bg-fondoClaro transition-colors"
              >
                <span className="text-sm font-semibold text-textoOscuro">{f.pregunta}</span>
                <motion.span
                  animate={{ rotate: abierta === f.id ? 180 : 0 }}
                  transition={{ duration: 0.2 }}
                  className="shrink-0 text-principal"
                >
                  <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
                    <path strokeLinecap="round" strokeLinejoin="round" d="M19 9l-7 7-7-7" />
                  </svg>
                </motion.span>
              </button>

              <AnimatePresence initial={false}>
                {abierta === f.id && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: 'auto', opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    transition={{ duration: 0.25, ease: 'easeOut' }}
                    className="overflow-hidden"
                  >
                    <p className="px-5 pb-4 text-sm text-gray-600 leading-relaxed whitespace-pre-line">
                      {f.respuesta}
                    </p>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          ))}
        </div>
      </div>

      <WidgetAtencion />
    </Layout>
  )
}