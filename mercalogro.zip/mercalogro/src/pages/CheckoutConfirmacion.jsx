import { useSearchParams, Link } from 'react-router-dom'
import { motion } from 'framer-motion'
import Layout from '../components/Layout.jsx'
import WidgetAtencion from '../components/WidgetAtencion.jsx'
import { productosPiloto } from '../data/productos.js'

export default function CheckoutConfirmacion() {
  const [params] = useSearchParams()
  const producto = productosPiloto.find((p) => p.id === params.get('producto'))

  return (
    <Layout>
      <div className="max-w-xl mx-auto px-4 py-16">
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3 }}
          className="bg-white rounded-2xl border border-gray-100 p-8 text-center"
        >
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ type: 'spring', stiffness: 200, damping: 15, delay: 0.1 }}
            className="w-16 h-16 mx-auto rounded-full bg-emerald-100 flex items-center justify-center"
          >
            <svg className="w-8 h-8 text-principal" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
            </svg>
          </motion.div>

          <h1 className="text-xl font-extrabold text-textoOscuro mt-4">Pedido confirmado</h1>
          <p className="text-sm text-gray-500 mt-2">
            Tu pedido {producto ? `de ${producto.nombre}` : ''} ha sido registrado.
          </p>

          <div className="mt-5 bg-fondoClaro rounded-xl p-4 text-left text-sm text-gray-600 space-y-1">
            <p>Pagas al momento de recibir tu producto.</p>
            <p>Tiempo máximo de entrega: 3 días hábiles, sujeto a disponibilidad.</p>
            <p>Puedes revisar el estado de tu compra en Mi cuenta.</p>
          </div>

          <div className="mt-6 flex flex-col sm:flex-row gap-3">
            <Link to="/mi-cuenta" className="flex-1">
              <motion.span
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                className="block bg-principal text-white font-bold py-3 rounded-xl hover:bg-emerald-800 transition-colors"
              >
                Ir a Mi cuenta
              </motion.span>
            </Link>
            <Link to="/" className="flex-1">
              <motion.span
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                className="block bg-fondoClaro text-textoOscuro font-bold py-3 rounded-xl hover:bg-gray-200 transition-colors"
              >
                Seguir comprando
              </motion.span>
            </Link>
          </div>
        </motion.div>
      </div>

      <WidgetAtencion />
    </Layout>
  )
}