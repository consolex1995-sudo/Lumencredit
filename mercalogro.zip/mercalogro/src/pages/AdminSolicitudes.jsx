import { useEffect, useState } from 'react'
import { motion } from 'framer-motion'
import { supabase } from '../lib/supabase.js'

function formatoFecha(f) {
  if (!f) return '—'
  return new Date(f).toLocaleString('es-MX', {
    day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit'
  })
}

export default function AdminSolicitudes() {
  const [solicitudes, setSolicitudes] = useState([])
  const [cargando, setCargando] = useState(true)
  const [error, setError] = useState('')

  async function cargar() {
    setCargando(true)
    const { data, error: err } = await supabase
      .from('solicitudes')
      .select('*')
      .order('creado_en', { ascending: false })
      .limit(100)

    if (err) setError('No pudimos cargar las solicitudes.')
    else setSolicitudes(data || [])
    setCargando(false)
  }

  useEffect(() => {
    cargar()
  }, [])

  async function cambiarEstado(id, nuevoEstado) {
    setError('')
    const { error: err } = await supabase
      .from('solicitudes')
      .update({ estado: nuevoEstado, revisado_en: new Date().toISOString() })
      .eq('id', id)

    if (err) {
      setError('No pudimos actualizar la solicitud.')
      return
    }
    setSolicitudes((s) => s.map((x) => (x.id === id ? { ...x, estado: nuevoEstado } : x)))
  }

  if (cargando) {
    return (
      <div className="bg-white rounded-2xl border border-gray-100 p-8 text-center">
        <div className="w-8 h-8 mx-auto border-4 border-principal border-t-transparent rounded-full animate-spin" />
      </div>
    )
  }

  return (
    <div className="space-y-3">
      {error && <p className="text-xs text-red-600">{error}</p>}

      {solicitudes.length === 0 ? (
        <div className="bg-white rounded-2xl border border-gray-100 p-8 text-center">
          <p className="text-sm text-gray-500">No hay solicitudes registradas.</p>
        </div>
      ) : (
        solicitudes.map((s) => (
          <motion.div
            key={s.id}
            initial={{ opacity: 0, y: 6 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white rounded-2xl border border-gray-100 p-4"
          >
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
              <div>
                <p className="text-sm font-bold text-textoOscuro">
                  {s.nombre_completo || 'Sin nombre'} — {s.producto_nombre || s.producto_id || 'Producto'}
                </p>
                <p className="text-xs text-gray-500 mt-0.5">
                  Creada: {formatoFecha(s.creado_en)}
                </p>
                <p className="text-xs text-gray-500">
                  Perfil: {s.perfil || '—'} · Ingresos: {s.ingresos || '—'} · Créditos: {s.creditos_activos ?? '—'}
                </p>
              </div>

              <div className="flex items-center gap-2">
                <span className={`text-[11px] font-bold px-2 py-1 rounded-full ${
                  s.estado === 'aprobada'
                    ? 'bg-emerald-100 text-principal'
                    : s.estado === 'rechazada'
                    ? 'bg-red-100 text-red-600'
                    : 'bg-amber-100 text-amber-700'
                }`}>
                  {s.estado === 'aprobada' ? 'Aprobada' : s.estado === 'rechazada' ? 'Rechazada' : 'Pendiente'}
                </span>
              </div>
            </div>

            {s.estado === 'pendiente' && (
              <div className="mt-3 flex gap-2">
                <button
                  onClick={() => cambiarEstado(s.id, 'aprobada')}
                  className="flex-1 bg-principal text-white text-xs font-bold py-2 rounded-xl hover:bg-emerald-800 transition-colors"
                >
                  Aprobar
                </button>
                <button
                  onClick={() => cambiarEstado(s.id, 'rechazada')}
                  className="flex-1 bg-red-600 text-white text-xs font-bold py-2 rounded-xl hover:bg-red-700 transition-colors"
                >
                  Rechazar
                </button>
              </div>
            )}
          </motion.div>
        ))
      )}
    </div>
  )
}