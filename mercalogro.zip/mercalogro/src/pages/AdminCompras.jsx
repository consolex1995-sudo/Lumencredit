import { useEffect, useState } from 'react'
import { motion } from 'framer-motion'
import { supabase } from '../lib/supabase.js'

function formatoMoneda(n) {
  return Number(n || 0).toLocaleString('es-MX', { style: 'currency', currency: 'MXN', maximumFractionDigits: 0 })
}

function formatoFecha(f) {
  if (!f) return '—'
  return new Date(f).toLocaleString('es-MX', {
    day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit'
  })
}

const ESTADOS = [
  { id: 'pendiente_pago', nombre: 'Pendiente de pago inicial' },
  { id: 'en_revision', nombre: 'En revisión' },
  { id: 'aprobada', nombre: 'Aprobada' },
  { id: 'procesando', nombre: 'Procesando' },
  { id: 'enviada', nombre: 'Enviada' },
  { id: 'entregada', nombre: 'Entregada' },
  { id: 'expirada', nombre: 'Expirada' },
  { id: 'cancelada', nombre: 'Cancelada' }
]

const CUENTAS_DISPONIBLES = [
  { id: 'CUENTA_A', nombre: 'Cuenta A (Dapp + PESPay)' },
  { id: 'CUENTA_B', nombre: 'Cuenta B (PESPay + Dapp)' },
  // Placeholders para futuras cuentas
  { id: 'CUENTA_C', nombre: 'Cuenta C (Pendiente)' },
  { id: 'CUENTA_D', nombre: 'Cuenta D (Pendiente)' },
  { id: 'CUENTA_E', nombre: 'Cuenta E (Pendiente)' }
]

export default function AdminCompras() {
  const [compras, setCompras] = useState([])
  const [cargando, setCargando] = useState(true)
  const [error, setError] = useState('')
  const [editandoId, setEditandoId] = useState(null)
  const [cuentaSeleccionada, setCuentaSeleccionada] = useState('CUENTA_A')
  const [diasDisponibles, setDiasDisponibles] = useState(3)

  async function cargar() {
    setCargando(true)
    const { data, error: err } = await supabase
      .from('compras')
      .select('*')
      .order('creado_en', { ascending: false })
      .limit(100)
    if (err) setError('No pudimos cargar las compras.')
    else setCompras(data || [])
    setCargando(false)
  }

  useEffect(() => {
    cargar()
  }, [])

  async function cambiarEstado(id, nuevoEstado) {
    setError('')
    const { error: err } = await supabase
      .from('compras')
      .update({ estado: nuevoEstado })
      .eq('id', id)
    if (err) {
      setError('No pudimos actualizar la compra.')
      return
    }
    setCompras((c) => c.map((x) => (x.id === id ? { ...x, estado: nuevoEstado } : x)))
  }

  async function aprobarConConfiguracion(id) {
    setError('')
    // Calcular fecha sumando los días seleccionados al día actual
    const fechaDisponible = new Date()
    fechaDisponible.setDate(fechaDisponible.getDate() + diasDisponibles)

    const { error: err } = await supabase
      .from('compras')
      .update({
        estado: 'aprobada',
        cuenta_asignada: cuentaSeleccionada,
        fecha_disponible: fechaDisponible.toISOString()
      })
      .eq('id', id)

    if (err) {
      setError('No pudimos aprobar la compra.')
      return
    }

    setCompras((c) => c.map((x) => x.id === id ? {
      ...x,
      estado: 'aprobada',
      cuenta_asignada: cuentaSeleccionada,
      fecha_disponible: fechaDisponible.toISOString()
    } : x))
    
    setEditandoId(null)
  }

  async function marcarEntregada(id) {
    await cambiarEstado(id, 'entregada')
    const hoy = new Date()
    const compra = compras.find((c) => c.id === id)
    if (!compra) return
    
    // Generar calendario de pagos solo si no existen ya
    const { data: pagosExistentes } = await supabase
      .from('pagos')
      .select('id')
      .eq('compra_id', id)
      .limit(1)
      
    if (!pagosExistentes || pagosExistentes.length === 0) {
      const pagos = []
      for (let i = 1; i <= 6; i++) {
        const venc = new Date(hoy)
        venc.setMonth(venc.getMonth() + i)
        pagos.push({
          compra_id: id,
          usuario_id: compra.usuario_id,
          monto: Math.round((compra.precio_total || 0) / 6),
          fecha_vencimiento: venc.toISOString(),
          estado: 'pendiente'
        })
      }
      await supabase.from('pagos').insert(pagos)
    }
  }

  if (cargando) {
    return (
      <div className="bg-white rounded-2xl border border-gray-100 p-8 text-center">
        <div className="w-8 h-8 mx-auto border-4 border-principal border-t-transparent rounded-full animate-spin" />
      </div>
    )
  }

  return (
    <div className="space-y-3">
      {error && <p className="text-xs text-red-600">{error}</p>}
      {compras.length === 0 ? (
        <div className="bg-white rounded-2xl border border-gray-100 p-8 text-center">
          <p className="text-sm text-gray-500">No hay compras registradas.</p>
        </div>
      ) : (
        compras.map((c) => (
          <motion.div
            key={c.id}
            initial={{ opacity: 0, y: 6 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white rounded-2xl border border-gray-100 p-4"
          >
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
              <div>
                <p className="text-sm font-bold text-textoOscuro">
                  {c.producto_nombre || c.producto_id} — {formatoMoneda(c.precio_total)}
                </p>
                <p className="text-xs text-gray-500 mt-0.5">
                  {c.tipo === 'contado' ? 'Contado' : 'A plazos'} · {formatoFecha(c.creado_en)}
                </p>
                {c.metodo_pago && (
                  <p className="text-xs text-gray-500">Método: {c.metodo_pago}</p>
                )}
                {c.cuenta_asignada && (
                  <p className="text-[11px] text-principal font-semibold mt-0.5">
                    Cuenta: {CUENTAS_DISPONIBLES.find(cta => cta.id === c.cuenta_asignada)?.nombre || c.cuenta_asignada}
                  </p>
                )}
                {c.fecha_disponible && (
                  <p className="text-[11px] text-emerald-700 font-semibold mt-0.5">
                    Disponible: {new Date(c.fecha_disponible).toLocaleDateString('es-MX', { weekday: 'short', day: 'numeric', month: 'short' })}
                  </p>
                )}
              </div>
              <span className={`text-[11px] font-bold px-2 py-1 rounded-full ${
                c.estado === 'entregada'
                  ? 'bg-emerald-100 text-principal'
                  : c.estado === 'expirada' || c.estado === 'cancelada'
                  ? 'bg-red-100 text-red-600'
                  : 'bg-amber-100 text-amber-700'
              }`}>
                {ESTADOS.find((e) => e.id === c.estado)?.nombre || c.estado}
              </span>
            </div>

            {/* PANEL DE APROBACIÓN CON CONFIGURACIÓN */}
            {c.estado === 'pendiente_pago' && editandoId === c.id && (
              <motion.div 
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: 'auto', opacity: 1 }}
                className="mt-3 pt-3 border-t border-gray-100 space-y-3"
              >
                <div>
                  <label className="block text-xs font-semibold text-gray-600 mb-1">Asignar cuenta de referencias</label>
                  <select
                    value={cuentaSeleccionada}
                    onChange={(e) => setCuentaSeleccionada(e.target.value)}
                    className="w-full border border-gray-200 rounded-xl px-3 py-2 text-sm outline-none focus:border-principal"
                  >
                    {CUENTAS_DISPONIBLES.map((cta) => (
                      <option key={cta.id} value={cta.id}>{cta.nombre}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-gray-600 mb-1">
                    Días para disponibilidad: <span className="text-principal font-bold">{diasDisponibles} días</span>
                  </label>
                  <input
                    type="range"
                    min={1}
                    max={15}
                    step={1}
                    value={diasDisponibles}
                    onChange={(e) => setDiasDisponibles(Number(e.target.value))}
                    className="w-full accent-principal"
                  />
                  <div className="flex justify-between text-[10px] text-gray-400 mt-1">
                    <span>1 día</span>
                    <span>15 días</span>
                  </div>
                  <p className="text-[11px] text-gray-500 mt-1">
                    El cliente verá esta fecha en su pantalla de pago.
                  </p>
                </div>

                <div className="flex gap-2">
                  <button
                    onClick={() => aprobarConConfiguracion(c.id)}
                    className="flex-1 bg-principal text-white text-xs font-bold py-2.5 rounded-xl hover:bg-emerald-800 transition-colors"
                  >
                    Confirmar aprobación
                  </button>
                  <button
                    onClick={() => setEditandoId(null)}
                    className="flex-1 bg-fondoClaro text-textoOscuro text-xs font-bold py-2.5 rounded-xl hover:bg-gray-200 transition-colors"
                  >
                    Cancelar
                  </button>
                </div>
              </motion.div>
            )}

            {/* BOTONES DE ACCIÓN RÁPIDA */}
            {editandoId !== c.id && (
              <div className="mt-3 flex flex-wrap gap-2">
                {c.estado === 'pendiente_pago' && (
                  <button
                    onClick={() => {
                      setEditandoId(c.id)
                      setCuentaSeleccionada(c.cuenta_asignada || 'CUENTA_A')
                      setDiasDisponibles(3)
                    }}
                    className="text-[11px] font-semibold px-3 py-1.5 rounded-lg bg-principal text-white hover:bg-emerald-800 transition-colors"
                  >
                    Aprobar y configurar
                  </button>
                )}
                
                {ESTADOS.filter((e) => e.id !== c.estado && e.id !== 'aprobada').map((e) => (
                  <button
                    key={e.id}
                    onClick={() =>
                      e.id === 'entregada' ? marcarEntregada(c.id) : cambiarEstado(c.id, e.id)
                    }
                    className="text-[11px] font-semibold px-3 py-1.5 rounded-lg border border-gray-200 hover:border-principal hover:text-principal transition-colors"
                  >
                    {e.nombre}
                  </button>
                ))}
              </div>
            )}
          </motion.div>
        ))
      )}
    </div>
  )
}