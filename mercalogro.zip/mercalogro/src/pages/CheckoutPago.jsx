import { useState } from 'react'
import { useSearchParams, useNavigate, Link } from 'react-router-dom'
import { motion } from 'framer-motion'
import Layout from '../components/Layout.jsx'
import WidgetAtencion from '../components/WidgetAtencion.jsx'
import { productosPiloto } from '../data/productos.js'
import { supabase } from '../lib/supabase.js'

function formatoMoneda(n) {
  return n.toLocaleString('es-MX', { style: 'currency', currency: 'MXN', maximumFractionDigits: 0 })
}

export default function CheckoutPago() {
  const [params] = useSearchParams()
  const navigate = useNavigate()
  const producto = productosPiloto.find((p) => p.id === params.get('producto'))

  const [metodo, setMetodo] = useState('')
  const [error, setError] = useState('')
  const [procesando, setProcesando] = useState(false)

  if (!producto) {
    return (
      <Layout>
        <div className="max-w-3xl mx-auto px-4 py-20 text-center">
          <p className="text-gray-500">Producto no encontrado.</p>
          <Link to="/" className="mt-4 inline-block text-principal font-semibold hover:underline">
            Volver a la tienda
          </Link>
        </div>
      </Layout>
    )
  }

  const envioGratis = producto.precioContado >= 600
  const total = producto.precioContado

  async function confirmar() {
    if (!metodo) {
      setError('Elige cómo pagarás al recibir tu producto.')
      return
    }

    setError('')
    setProcesando(true)

    try {
      const { data } = await supabase.auth.getSession()
      if (!data?.session) {
        navigate(`/checkout-contado?producto=${producto.id}`)
        return
      }

      const { error: err } = await supabase.from('compras').insert({
        usuario_id: data.session.user.id,
        producto_id: producto.id,
        producto_nombre: producto.nombre,
        precio_total: total,
        tipo: 'contado',
        metodo_pago: metodo,
        envio_gratis: envioGratis,
        estado: 'pendiente_envio'
      })

      if (err) {
        setError('No pudimos registrar tu pedido. Intenta de nuevo.')
        setProcesando(false)
        return
      }

      navigate(`/checkout-contado/confirmacion?producto=${producto.id}`)
    } catch {
      setError('Ocurrió un error. Intenta de nuevo.')
      setProcesando(false)
    }
  }

  return (
    <Layout>
      <div className="max-w-3xl mx-auto px-4 py-8">
        <h1 className="text-2xl font-extrabold text-textoOscuro tracking-tight">Pago contraentrega</h1>
        <p className="text-sm text-gray-500 mt-1">Pagas al recibir tu producto en tu domicilio.</p>

        <motion.div
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.25 }}
          className="mt-6 bg-white rounded-2xl border border-gray-100 p-5 space-y-4"
        >
          <div className="flex items-center justify-between">
            <span className="text-sm text-gray-600">{producto.nombre}</span>
            <span className="font-bold text-textoOscuro">{formatoMoneda(total)}</span>
          </div>
          <div className="flex items-center justify-between border-t border-gray-100 pt-3">
            <span className="text-sm text-gray-600">Envío</span>
            <span className="font-semibold text-principal">
              {envioGratis ? 'Gratis' : 'Se cobra al recibir'}
            </span>
          </div>

          <div className="border-t border-gray-100 pt-4">
            <p className="text-sm font-bold text-textoOscuro mb-2">¿Cómo pagarás al recibir?</p>
            <div className="grid sm:grid-cols-2 gap-3">
              <button
                onClick={() => setMetodo('efectivo')}
                className={`text-left border rounded-xl p-4 transition-colors ${
                  metodo === 'efectivo' ? 'border-principal bg-emerald-50' : 'border-gray-200 hover:border-principal'
                }`}
              >
                <p className="font-bold text-textoOscuro">Efectivo</p>
                <p className="text-xs text-gray-500 mt-1">Ten el monto listo al recibir.</p>
              </button>

              <button
                onClick={() => setMetodo('tarjeta')}
                className={`text-left border rounded-xl p-4 transition-colors ${
                  metodo === 'tarjeta' ? 'border-principal bg-emerald-50' : 'border-gray-200 hover:border-principal'
                }`}
              >
                <p className="font-bold text-textoOscuro">Tarjeta</p>
                <p className="text-xs text-gray-500 mt-1">Crédito o débito.</p>
              </button>
            </div>

            {metodo === 'tarjeta' && (
              <p className="mt-3 text-xs text-gray-500">
                Revisa con anticipación la disponibilidad de saldo en tu tarjeta.
              </p>
            )}
          </div>

          {error && <p className="text-xs text-red-600">{error}</p>}

          <motion.button
            whileHover={{ scale: 1.01 }}
            whileTap={{ scale: 0.99 }}
            onClick={confirmar}
            disabled={procesando}
            className="w-full bg-principal text-white font-bold py-3 rounded-xl hover:bg-emerald-800 transition-colors disabled:opacity-60"
          >
            {procesando ? 'Procesando…' : 'Confirmar pedido'}
          </motion.button>
        </motion.div>
      </div>

      <WidgetAtencion />
    </Layout>
  )
}