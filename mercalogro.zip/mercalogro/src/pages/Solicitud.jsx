import { Routes, Route, Navigate } from 'react-router-dom'
import SolicitudIntro1 from './solicitud/SolicitudIntro1.jsx'
import SolicitudIntro2 from './solicitud/SolicitudIntro2.jsx'
import SolicitudDatosPersonales from './solicitud/SolicitudDatosPersonales.jsx'
import SolicitudDatosLaborales from './solicitud/SolicitudDatosLaborales.jsx'
import SolicitudBiometria from './solicitud/SolicitudBiometria.jsx'
import SolicitudAuditoria from './solicitud/SolicitudAuditoria.jsx'
import SolicitudEstado from './solicitud/SolicitudEstado.jsx'

export default function Solicitud() {
  return (
    <Routes>
      <Route index element={<Navigate to="intro" replace />} />
      <Route path="intro" element={<SolicitudIntro1 />} />
      <Route path="intro-2" element={<SolicitudIntro2 />} />
      <Route path="datos-personales" element={<SolicitudDatosPersonales />} />
      <Route path="datos-laborales" element={<SolicitudDatosLaborales />} />
      <Route path="biometria" element={<SolicitudBiometria />} />
      <Route path="auditoria" element={<SolicitudAuditoria />} />
      <Route path="estado" element={<SolicitudEstado />} />
      <Route path="*" element={<Navigate to="intro" replace />} />
    </Routes>
  )
}