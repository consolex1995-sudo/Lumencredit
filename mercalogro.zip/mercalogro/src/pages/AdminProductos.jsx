import { useEffect, useState } from 'react'
import { motion } from 'framer-motion'
import { supabase } from '../lib/supabase.js'

const VACIO = {
  id: null,
  nombre: '',
  categoria: 'consolas',
  imagen: '',
  precio_contado: '',
  precio_anterior: '',
  precio_plazos: '',
  stock: 0,
  stock_bajo: false,
  alta_demanda: false,
  descripcion: ''
}

export default function AdminProductos() {
  const [productos, setProductos] = useState([])
  const [cargando, setCargando] = useState(true)
  const [editando, setEditando] = useState(null)
  const [error, setError] = useState('')
  const [guardando, setGuardando] = useState(false)

  async function cargar() {
    setCargando(true)
    const { data, error: err } = await supabase
      .from('productos')
      .select('*')
      .order('creado_en', { ascending: false })

    if (err) setError('No pudimos cargar los productos.')
    else setProductos(data || [])
    setCargando(false)
  }

  useEffect(() => {
    cargar()
  }, [])

  function nuevo() {
    setEditando({ ...VACIO })
    setError('')
  }

  function editar(p) {
    setEditando({
      ...p,
      precio_contado: String(p.precio_contado ?? ''),
      precio_anterior: p.precio_anterior ? String(p.precio_anterior) : '',
      precio_plazos: String(p.precio_plazos ?? '')
    })
    setError('')
  }

  function cambiar(campo, valor) {
    setEditando((e) => ({ ...e, [campo]: valor }))
  }

  async function guardar(e) {
    e.preventDefault()
    setError('')

    if (!editando.nombre.trim()) {
      setError('El nombre es obligatorio.')
      return
    }
    if (!editando.precio_contado) {
      setError('El precio de contado es obligatorio.')
      return
    }

    setGuardando(true)
    const payload = {
      nombre: editando.nombre.trim(),
      categoria: editando.categoria,
      imagen: editando.imagen.trim(),
      precio_contado: Number(editando.precio_contado),
      precio_anterior: editando.precio_anterior ? Number(editando.precio_anterior) : null,
      precio_plazos: editando.precio_plazos ? Number(editando.precio_plazos) : null,
      stock: Number(editando.stock) || 0,
      stock_bajo: !!editando.stock_bajo,
      alta_demanda: !!editando.alta_demanda,
      descripcion: editando.descripcion.trim()
    }

    let err
    if (editando.id) {
      ;({ error: err } = await supabase.from('productos').update(payload).eq('id', editando.id))
    } else {
      ;({ error: err } = await supabase.from('productos').insert(payload))
    }

    if (err) {
      setError('No pudimos guardar el producto.')
      setGuardando(false)
      return
    }

    setGuardando(false)
    setEditando(null)
    cargar()
  }

  async function eliminar(id) {
    if (!confirm('¿Eliminar este producto?')) return
    const { error: err } = await supabase.from('productos').delete().eq('id', id)
    if (err) {
      setError('No pudimos eliminar el producto.')
      return
    }
    setProductos((p) => p.filter((x) => x.id !== id))
  }

  if (cargando) {
    return (
      <div className="bg-white rounded-2xl border border-gray-100 p-8 text-center">
        <div className="w-8 h-8 mx-auto border-4 border-principal border-t-transparent rounded-full animate-spin" />
      </div>
    )
  }

  return (
    <div className="space-y-4">
      {error && <p className="text-xs text-red-600">{error}</p>}

      {!editando && (
        <button
          onClick={nuevo}
          className="bg-principal text-white text-sm font-bold px-4 py-2 rounded-xl hover:bg-emerald-800 transition-colors"
        >
          + Nuevo producto
        </button>
      )}

      {editando && (
        <motion.form
          initial={{ opacity: 0, y: 6 }}
          animate={{ opacity: 1, y: 0 }}
          onSubmit={guardar}
          className="bg-white rounded-2xl border border-gray-100 p-5 space-y-3"
        >
          <h3 className="font-bold text-textoOscuro">
            {editando.id ? 'Editar producto' : 'Nuevo producto'}
          </h3>

          <div className="grid sm:grid-cols-2 gap-3">
            <Campo label="Nombre" valor={editando.nombre} cambiar={(v) => cambiar('nombre', v)} />
            <div>
              <label className="block text-xs font-semibold text-gray-600 mb-1">Categoría</label>
              <select
                value={editando.categoria}
                onChange={(e) => cambiar('categoria', e.target.value)}
                className="w-full border border-gray-200 rounded-xl px-3 py-2 text-sm outline-none focus:border-principal"
              >
                <option value="consolas">Consolas</option>
                <option value="juegos">Juegos</option>
                <option value="accesorios">Accesorios</option>
                <option value="sillas">Sillas</option>
              </select>
            </div>
            <Campo label="Link de imagen" valor={editando.imagen} cambiar={(v) => cambiar('imagen', v)} />
            <Campo label="Precio contado" valor={editando.precio_contado} cambiar={(v) => cambiar('precio_contado', v.replace(/[^\d.]/g, ''))} inputMode="decimal" />
            <Campo label="Precio anterior (opcional)" valor={editando.precio_anterior} cambiar={(v) => cambiar('precio_anterior', v.replace(/[^\d.]/g, ''))} inputMode="decimal" />
            <Campo label="Precio a plazos (opcional)" valor={editando.precio_plazos} cambiar={(v) => cambiar('precio_plazos', v.replace(/[^\d.]/g, ''))} inputMode="decimal" />
            <Campo label="Stock" valor={String(editando.stock)} cambiar={(v) => cambiar('stock', v.replace(/\D/g, ''))} inputMode="numeric" />
          </div>

          <div>
            <label className="block text-xs font-semibold text-gray-600 mb-1">Descripción</label>
            <textarea
              value={editando.descripcion}
              onChange={(e) => cambiar('descripcion', e.target.value)}
              rows={3}
              className="w-full border border-gray-200 rounded-xl px-3 py-2 text-sm outline-none focus:border-principal resize-none"
            />
          </div>

          <div className="flex gap-4 text-sm">
            <label className="flex items-center gap-2">
              <input
                type="checkbox"
                checked={!!editando.stock_bajo}
                onChange={(e) => cambiar('stock_bajo', e.target.checked)}
                className="accent-principal"
              />
              Se agota
            </label>
            <label className="flex items-center gap-2">
              <input
                type="checkbox"
                checked={!!editando.alta_demanda}
                onChange={(e) => cambiar('alta_demanda', e.target.checked)}
                className="accent-principal"
              />
              Alta demanda
            </label>
          </div>

          <div className="flex gap-2">
            <button
              type="submit"
              disabled={guardando}
              className="flex-1 bg-principal text-white font-bold py-2.5 rounded-xl hover:bg-emerald-800 transition-colors disabled:opacity-60"
            >
              {guardando ? 'Guardando…' : 'Guardar'}
            </button>
            <button
              type="button"
              onClick={() => setEditando(null)}
              className="flex-1 bg-fondoClaro text-textoOscuro font-bold py-2.5 rounded-xl hover:bg-gray-200 transition-colors"
            >
              Cancelar
            </button>
          </div>
        </motion.form>
      )}

      <div className="space-y-2">
        {productos.map((p) => (
          <div
            key={p.id}
            className="bg-white rounded-2xl border border-gray-100 p-3 flex items-center justify-between gap-3"
          >
            <div>
              <p className="text-sm font-bold text-textoOscuro">{p.nombre}</p>
              <p className="text-xs text-gray-500">
                {p.categoria} · ${p.precio_contado} · Stock: {p.stock}
              </p>
            </div>
            <div className="flex gap-2">
              <button
                onClick={() => editar(p)}
                className="text-xs font-semibold text-principal hover:underline"
              >
                Editar
              </button>
              <button
                onClick={() => eliminar(p.id)}
                className="text-xs font-semibold text-red-600 hover:underline"
              >
                Eliminar
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}

function Campo({ label, valor, cambiar, inputMode }) {
  return (
    <div>
      <label className="block text-xs font-semibold text-gray-600 mb-1">{label}</label>
      <input
        type="text"
        value={valor}
        inputMode={inputMode}
        onChange={(e) => cambiar(e.target.value)}
        className="w-full border border-gray-200 rounded-xl px-3 py-2 text-sm outline-none focus:border-principal"
      />
    </div>
  )
}