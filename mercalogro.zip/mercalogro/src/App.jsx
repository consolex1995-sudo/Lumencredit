import { useEffect } from 'react'
import { Routes, Route, Navigate } from 'react-router-dom'
import Tienda from './pages/Tienda.jsx'
import Producto from './pages/Producto.jsx'
import PreguntasFrecuentes from './pages/PreguntasFrecuentes.jsx'
import Testimonios from './pages/Testimonios.jsx'
import Legales from './pages/Legales.jsx'
import MiCuenta from './pages/MiCuenta.jsx'
import Solicitud from './pages/Solicitud.jsx'
import AdminLogin from './pages/AdminLogin.jsx'
import AdminPanel from './pages/AdminPanel.jsx'
import CheckoutContado from './pages/CheckoutContado.jsx'
import CheckoutPago from './pages/CheckoutPago.jsx'
import CheckoutConfirmacion from './pages/CheckoutConfirmacion.jsx'
import PagoInicial from './pages/PagoInicial.jsx'
import RutaProtegida from './components/RutaProtegida.jsx'
import RutaAdmin from './components/RutaAdmin.jsx'

export default function App() {
  useEffect(() => {
    const yaRegistrada = sessionStorage.getItem('mercalogro_visita_registrada')
    if (!yaRegistrada) {
      fetch('/.netlify/functions/registrar-visita', { method: 'POST' }).catch(() => {})
      sessionStorage.setItem('mercalogro_visita_registrada', 'true')
    }
  }, [])

  return (
    <Routes>
      <Route path="/" element={<Tienda />} />
      <Route path="/producto/:id" element={<Producto />} />
      <Route path="/preguntas-frecuentes" element={<PreguntasFrecuentes />} />
      <Route path="/testimonios" element={<Testimonios />} />
      <Route path="/legales" element={<Legales />} />

      <Route
        path="/mi-cuenta"
        element={
          <RutaProtegida>
            <MiCuenta />
          </RutaProtegida>
        }
      />

      <Route
        path="/solicitud/*"
        element={
          <RutaProtegida>
            <Solicitud />
          </RutaProtegida>
        }
      />

      <Route
        path="/checkout-contado"
        element={
          <RutaProtegida>
            <CheckoutContado />
          </RutaProtegida>
        }
      />
      <Route
        path="/checkout-contado/pago"
        element={
          <RutaProtegida>
            <CheckoutPago />
          </RutaProtegida>
        }
      />
      <Route
        path="/checkout-contado/confirmacion"
        element={
          <RutaProtegida>
            <CheckoutConfirmacion />
          </RutaProtegida>
        }
      />
      <Route
        path="/pago-inicial"
        element={
          <RutaProtegida>
            <PagoInicial />
          </RutaProtegida>
        }
      />

      <Route path="/acceso-interno" element={<AdminLogin />} />

      <Route
        path="/admin"
        element={
          <RutaAdmin>
            <AdminPanel />
          </RutaAdmin>
        }
      />

      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  )
}