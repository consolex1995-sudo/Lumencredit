const TELEGRAM_API = 'https://api.telegram.org/bot'

export async function handler(event) {
  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, body: JSON.stringify({ ok: false }) }
  }

  const token = process.env.TELEGRAM_BOT_COMPROBANTES_TOKEN
  const chatId = process.env.TELEGRAM_CHAT_COMPROBANTES_ID

  if (!token || !chatId) {
    return {
      statusCode: 500,
      body: JSON.stringify({ ok: false, error: 'Faltan variables de entorno.' })
    }
  }

  try {
    const { imagen, compraId, monto, tipo } = JSON.parse(event.body || '{}')

    if (!imagen) {
      return { statusCode: 400, body: JSON.stringify({ ok: false, error: 'Falta la imagen.' }) }
    }

    const caption = [
      '<b>Nuevo comprobante recibido</b>',
      `Compra: ${compraId || '—'}`,
      `Monto: $${monto ?? '—'} MXN`,
      `Tipo: ${tipo || 'pago_inicial'}`
    ].join('\n')

    const match = /^data:image\/(\w+);base64,(.+)$/.exec(imagen)
    if (!match) {
      return { statusCode: 400, body: JSON.stringify({ ok: false, error: 'Formato de imagen inválido.' }) }
    }

    const [, ext, data] = match
    const buffer = Buffer.from(data, 'base64')
    const form = new FormData()
    form.append('chat_id', chatId)
    form.append('caption', caption)
    form.append('parse_mode', 'HTML')
    form.append('photo', new Blob([buffer], { type: `image/${ext}` }), `comprobante.${ext}`)

    const res = await fetch(`${TELEGRAM_API}${token}/sendPhoto`, {
      method: 'POST',
      body: form
    })

    const respuesta = await res.json()

    if (respuesta.ok === false && respuesta.parameters?.migrate_to_chat_id) {
      const nuevoChatId = respuesta.parameters.migrate_to_chat_id
      form.set('chat_id', nuevoChatId)
      await fetch(`${TELEGRAM_API}${token}/sendPhoto`, {
        method: 'POST',
        body: form
      })
      return {
        statusCode: 200,
        body: JSON.stringify({
          ok: true,
          migrado: true,
          nuevo_chat_id: nuevoChatId,
          aviso: 'Actualiza TELEGRAM_CHAT_COMPROBANTES_ID con el nuevo ID.'
        })
      }
    }

    if (!respuesta.ok) {
      return {
        statusCode: 500,
        body: JSON.stringify({ ok: false, error: 'No pudimos enviar el comprobante.' })
      }
    }

    return {
      statusCode: 200,
      body: JSON.stringify({ ok: true, imagenUrl: respuesta.result?.photo?.slice(-1)?.[0]?.file_id || '' })
    }
  } catch {
    return {
      statusCode: 500,
      body: JSON.stringify({ ok: false, error: 'No pudimos procesar el comprobante.' })
    }
  }
}