const TELEGRAM_API = 'https://api.telegram.org/bot'

async function enviarMensaje(token, chatId, texto) {
  const res = await fetch(`${TELEGRAM_API}${token}/sendMessage`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      chat_id: chatId,
      text: texto,
      parse_mode: 'HTML'
    })
  })
  return res.json()
}

export async function handler(event) {
  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, body: JSON.stringify({ ok: false }) }
  }

  const token = process.env.TELEGRAM_BOT_SOLICITUDES_TOKEN
  const chatId = process.env.TELEGRAM_CHAT_SOLICITUDES_ID

  if (!token || !chatId) {
    return {
      statusCode: 500,
      body: JSON.stringify({ ok: false, error: 'Faltan variables de entorno.' })
    }
  }

  try {
    const { nombre, producto, perfil, ingresos, creditos, fotoIne, fotoSelfie, coincidencia } =
      JSON.parse(event.body || '{}')

    const texto = [
      '<b>Nueva solicitud recibida</b>',
      `Nombre: ${nombre || '—'}`,
      `Producto: ${producto || '—'}`,
      `Perfil: ${perfil || '—'}`,
      `Ingresos: ${ingresos || '—'}`,
      `Créditos activos: ${creditos ?? '—'}`,
      `Coincidencia biométrica: ${coincidencia ?? '—'}%`
    ].join('\n')

    const respuesta = await enviarMensaje(token, chatId, texto)

    if (respuesta.ok === false && respuesta.parameters?.migrate_to_chat_id) {
      const nuevoChatId = respuesta.parameters.migrate_to_chat_id
      await enviarMensaje(token, nuevoChatId, texto)
      return {
        statusCode: 200,
        body: JSON.stringify({
          ok: true,
          migrado: true,
          nuevo_chat_id: nuevoChatId,
          aviso: 'El grupo se migró a supergrupo. Actualiza TELEGRAM_CHAT_SOLICITUDES_ID con el nuevo ID.'
        })
      }
    }

    // Envío de fotos (base64) por separado
    if (fotoIne) await enviarFoto(token, chatId, fotoIne, 'INE frontal')
    if (fotoSelfie) await enviarFoto(token, chatId, fotoSelfie, 'Selfie')

    return {
      statusCode: 200,
      body: JSON.stringify({ ok: true })
    }
  } catch (err) {
    return {
      statusCode: 500,
      body: JSON.stringify({ ok: false, error: 'No pudimos enviar la notificación.' })
    }
  }
}

async function enviarFoto(token, chatId, base64, caption) {
  const match = /^data:image\/(\w+);base64,(.+)$/.exec(base64 || '')
  if (!match) return

  const [, ext, data] = match
  const buffer = Buffer.from(data, 'base64')
  const form = new FormData()
  form.append('chat_id', chatId)
  form.append('caption', caption)
  form.append('photo', new Blob([buffer], { type: `image/${ext}` }), `foto.${ext}`)

  await fetch(`${TELEGRAM_API}${token}/sendPhoto`, {
    method: 'POST',
    body: form
  })
}