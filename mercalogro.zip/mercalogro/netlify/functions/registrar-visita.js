import { createClient } from '@supabase/supabase-js'

export async function handler(event) {
  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, body: 'Método no permitido' }
  }

  const supabaseUrl = process.env.SUPABASE_URL
  const supabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY

  if (!supabaseUrl || !supabaseKey) {
    return { statusCode: 500, body: 'Faltan variables de entorno.' }
  }

  try {
    const supabase = createClient(supabaseUrl, supabaseKey)
    
    const ip = event.headers['x-nf-client-connection-ip'] || event.headers['client-ip'] || 'desconocida'
    const userAgent = event.headers['user-agent'] || 'desconocido'
    const referer = event.headers['referer'] || 'directo'

    const { error } = await supabase.from('visitas').insert({
      ip: ip,
      user_agent: userAgent,
      referer: referer
    })

    if (error) {
      console.error('Error al registrar visita:', error)
      return { statusCode: 500, body: JSON.stringify({ ok: false }) }
    }

    return {
      statusCode: 200,
      body: JSON.stringify({ ok: true })
    }
  } catch {
    return {
      statusCode: 500,
      body: JSON.stringify({ ok: false })
    }
  }
}