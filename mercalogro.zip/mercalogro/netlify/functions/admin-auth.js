export async function handler(event) {
  if (event.httpMethod !== 'POST') {
    return {
      statusCode: 405,
      body: JSON.stringify({ ok: false, error: 'Método no permitido' })
    }
  }

  try {
    const { usuario, password, token } = JSON.parse(event.body || '{}')

    const usuarioCorrecto = process.env.ADMIN_USUARIO
    const passwordCorrecta = process.env.ADMIN_PASSWORD
    const tokenCorrecto = process.env.ADMIN_TOKEN

    if (!usuarioCorrecto || !passwordCorrecta || !tokenCorrecto) {
      return {
        statusCode: 500,
        body: JSON.stringify({ ok: false, error: 'Faltan variables de entorno del admin.' })
      }
    }

    const ok =
      usuario === usuarioCorrecto &&
      password === passwordCorrecta &&
      token === tokenCorrecto

    if (!ok) {
      return {
        statusCode: 401,
        body: JSON.stringify({ ok: false, error: 'Credenciales incorrectas.' })
      }
    }

    return {
      statusCode: 200,
      body: JSON.stringify({ ok: true })
    }
  } catch {
    return {
      statusCode: 400,
      body: JSON.stringify({ ok: false, error: 'Solicitud inválida.' })
    }
  }
}