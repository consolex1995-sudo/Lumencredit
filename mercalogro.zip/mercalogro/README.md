# Mercalogro

Tienda en línea de consolas, videojuegos, accesorios y sillas, con compra de contado y a plazos (6 meses).

## Stack
- React + Vite
- Tailwind CSS
- Framer Motion
- Supabase
- Netlify Functions

## Instalación local (opcional)
Si tienes PC:
1. `npm install`
2. `npm run dev`

## Variables de entorno en Netlify
En el panel de Netlify, en *Site settings > Environment variables*, configura:
- `VITE_SUPABASE_URL`
- `VITE_SUPABASE_ANON_KEY`
- `SUPABASE_URL`
- `SUPABASE_SERVICE_ROLE_KEY`
- `TELEGRAM_BOT_SOLICITUDES_TOKEN`
- `TELEGRAM_CHAT_SOLICITUDES_ID`
- `TELEGRAM_BOT_COMPROBANTES_TOKEN`
- `TELEGRAM_CHAT_COMPROBANTES_ID`
- `ADMIN_USUARIO`
- `ADMIN_PASSWORD`
- `ADMIN_TOKEN`

## Despliegue
1. Sube el proyecto a un repositorio de GitHub.
2. Conecta el repositorio en Netlify.
3. Netlify ejecutará `npm run build` y publicará la carpeta `dist`.
4. Configura las variables de entorno.
5. Listo. El dominio se asigna en Netlify o en Porkbun.

## Rutas del proyecto
- `/` — Tienda
- `/producto/:id` — Detalle de producto
- `/mi-cuenta` — Panel del cliente
- `/solicitud/*` — Flujo de solicitud a plazos
- `/preguntas-frecuentes` — FAQ
- `/legales` — Términos y aviso de privacidad
- `/acceso-interno` — Login secreto del admin
- `/admin` — Panel de administración (protegido)